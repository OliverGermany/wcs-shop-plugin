<?php

/**
 * WCS Content Parser
 *
 * Parst KI-generierten HTML-Text (H2+P+UL) in strukturierte Layout-Slots.
 * PHP-Port des C# LayoutContentParser.cs - identische Logik.
 *
 * @package WCS Structured Data
 * @version 1.5.0
 */

declare(strict_types=1);

namespace Plugin\wcsstructureddata;

class WcsContentParser
{
    private const FAQ_KEYWORDS = [
        'faq', 'häufige fragen', 'haeufige fragen', 'frequently asked',
        'fragen und antworten', 'fragen & antworten',
    ];

    private const TECH_KEYWORDS = [
        'technische', 'spezifikation', 'technical', 'datenblatt',
        'technische details', 'technische daten', 'technische informationen',
    ];

    private const NOTICE_KEYWORDS = [
        'hinweis', 'wichtig', 'notice', 'achtung', 'disclaimer',
    ];

    /**
     * Parst HTML-Text in strukturierten Layout-Content.
     *
     * @param string $html       KI-generierter HTML-Text (H2+P+UL)
     * @param string $artikelName Produktname fuer den Hero-Bereich
     * @param string $kategorie  Kategorie fuer den Tag (optional)
     * @return array             Strukturierter Content
     */
    public function parse(string $html, string $artikelName, string $kategorie = ''): array
    {
        $content = [
            'tag'         => $kategorie,
            'title'       => $artikelName,
            'subtitle'    => '',
            'badges'      => [],
            'highlight'   => null,
            'sections'    => [],
            'faq'         => null,
            'techSpecs'   => null,
            'noticeTitle' => '',
            'noticeText'  => '',
        ];

        if (empty(trim($html))) {
            $content['subtitle'] = $artikelName;
            return $content;
        }

        // HTML in Bloecke zerlegen (Split an H2)
        $blocks = $this->splitByH2($html);

        // Ersten Block als Subtitle/Highlight verwenden (Text VOR erster H2)
        if (count($blocks) > 0 && empty($blocks[0]['title'])) {
            $introBlock = $blocks[0];
            if (count($introBlock['paragraphs']) > 0) {
                $content['subtitle'] = $introBlock['paragraphs'][0];
                if (count($introBlock['paragraphs']) > 1) {
                    $content['highlight'] = [
                        'title' => $this->truncateToPhrase($this->stripHtml($introBlock['paragraphs'][1]), 60),
                        'text'  => $introBlock['paragraphs'][1],
                    ];
                }
            }
            array_shift($blocks);
        }

        // Wenn erste H2 existiert und noch kein Subtitle
        if (empty($content['subtitle']) && count($blocks) > 0) {
            $firstBlock = &$blocks[0];
            if (count($firstBlock['paragraphs']) > 0) {
                $content['subtitle'] = $firstBlock['paragraphs'][0];

                // Highlight aus zweitem Absatz
                if (count($firstBlock['paragraphs']) > 1) {
                    $content['highlight'] = [
                        'title' => $this->cleanTitle($firstBlock['title']),
                        'text'  => $firstBlock['paragraphs'][1],
                    ];
                }

                // Ersten Absatz entfernen (ist jetzt Subtitle)
                array_shift($firstBlock['paragraphs']);
                if (count($firstBlock['paragraphs']) === 0 && count($firstBlock['listItems']) === 0) {
                    array_shift($blocks);
                }
            }
            unset($firstBlock);
        }

        // Badges extrahieren
        $content['badges'] = $this->extractBadges($html);

        // Restliche Bloecke klassifizieren
        foreach ($blocks as $block) {
            $titleLower = mb_strtolower(trim($block['title']));

            // FAQ erkennen
            if ($this->matchesKeywords($titleLower, self::FAQ_KEYWORDS)) {
                $faq = $this->parseFaqBlock($block);
                if ($faq !== null) {
                    $content['faq'] = $faq;
                }
                continue;
            }

            // Tech-Specs erkennen
            if ($this->matchesKeywords($titleLower, self::TECH_KEYWORDS)) {
                $specs = $this->parseTechSpecsBlock($block);
                if ($specs !== null) {
                    $content['techSpecs'] = $specs;
                }
                continue;
            }

            // Notice/Hinweis erkennen
            if ($this->matchesKeywords($titleLower, self::NOTICE_KEYWORDS)) {
                $content['noticeTitle'] = $this->cleanTitle($block['title']);
                $texts = array_map([$this, 'stripHtml'], $block['paragraphs']);
                $content['noticeText'] = implode(' ', $texts);
                if (count($block['listItems']) > 0) {
                    $liTexts = array_map([$this, 'stripHtml'], $block['listItems']);
                    $content['noticeText'] .= ' ' . implode(' ', $liTexts);
                }
                continue;
            }

            // Normale Section
            $content['sections'][] = [
                'title'      => $this->cleanTitle($block['title']),
                'paragraphs' => $block['paragraphs'],
                'listItems'  => $block['listItems'],
            ];
        }

        // Highlight-Fallback: ersten Section-Absatz verwenden
        if ($content['highlight'] === null && count($content['sections']) > 0) {
            $firstSection = $content['sections'][0];
            if (count($firstSection['paragraphs']) > 0) {
                $content['highlight'] = [
                    'title' => $this->cleanTitle($firstSection['title']),
                    'text'  => $firstSection['paragraphs'][0],
                ];
            }
        }

        return $content;
    }

    // =========================================================
    // HTML in H2-Bloecke zerlegen
    // =========================================================

    private function splitByH2(string $html): array
    {
        $blocks = [];
        $current = ['title' => '', 'paragraphs' => [], 'listItems' => [], 'h3Pairs' => []];

        $pattern = '/<h2[^>]*>(.*?)<\/h2>|<h3[^>]*>(.*?)<\/h3>|<p[^>]*>(.*?)<\/p>|<li[^>]*>(.*?)<\/li>/si';
        preg_match_all($pattern, $html, $matches, PREG_SET_ORDER);

        $lastH3 = null;

        foreach ($matches as $m) {
            if (!empty($m[1]) || (isset($m[1]) && $m[1] === '0')) {
                // H2
                if (!empty($current['title']) || count($current['paragraphs']) > 0 || count($current['listItems']) > 0) {
                    $blocks[] = $current;
                }
                $current = [
                    'title'      => trim($this->stripHtml($m[1])),
                    'paragraphs' => [],
                    'listItems'  => [],
                    'h3Pairs'    => [],
                ];
                $lastH3 = null;
            } elseif (isset($m[2]) && $m[2] !== '') {
                // H3
                $lastH3 = trim($this->stripHtml($m[2]));
            } elseif (isset($m[3]) && $m[3] !== '') {
                // P
                $pContent = trim($m[3]);
                if (empty(trim($this->stripHtml($pContent)))) {
                    continue;
                }

                if ($lastH3 !== null) {
                    $current['h3Pairs'][] = ['question' => $lastH3, 'answer' => $pContent];
                    $lastH3 = null;
                } else {
                    $current['paragraphs'][] = $pContent;
                }
            } elseif (isset($m[4]) && $m[4] !== '') {
                // LI
                $liContent = trim($m[4]);
                if (!empty(trim($this->stripHtml($liContent)))) {
                    $current['listItems'][] = $liContent;
                }
            }
        }

        // Letzten Block speichern
        if (!empty($current['title']) || count($current['paragraphs']) > 0
            || count($current['listItems']) > 0 || count($current['h3Pairs']) > 0) {
            $blocks[] = $current;
        }

        return $blocks;
    }

    // =========================================================
    // FAQ parsen (H3+P Paare)
    // =========================================================

    private function parseFaqBlock(array $block): ?array
    {
        $faq = [
            'title'         => $this->cleanTitle($block['title']),
            'items'         => [],
            'includeJsonLd' => true,
        ];

        // H3+P Paare
        foreach ($block['h3Pairs'] as $pair) {
            $faq['items'][] = [
                'question' => $pair['question'],
                'answer'   => $this->stripHtml($pair['answer']),
            ];
        }

        // Fallback: P-Paare mit Frage-Erkennung
        if (count($faq['items']) === 0 && count($block['paragraphs']) > 0) {
            $count = count($block['paragraphs']);
            for ($i = 0; $i < $count - 1; $i += 2) {
                $q = $this->stripHtml($block['paragraphs'][$i]);
                $a = ($i + 1 < $count) ? $this->stripHtml($block['paragraphs'][$i + 1]) : '';
                if (str_ends_with($q, '?') || str_contains($block['paragraphs'][$i], '<strong>')) {
                    $faq['items'][] = ['question' => $q, 'answer' => $a];
                }
            }
        }

        return count($faq['items']) > 0 ? $faq : null;
    }

    // =========================================================
    // Tech-Specs parsen
    // =========================================================

    private function parseTechSpecsBlock(array $block): ?array
    {
        $specs = [
            'title'      => $this->cleanTitle($block['title']),
            'leftItems'  => [],
            'rightItems' => [],
        ];

        $allItems = $block['listItems'];

        // In 2 Spalten aufteilen
        $halfPoint = (int)ceil(count($allItems) / 2);
        $specs['leftItems'] = array_slice($allItems, 0, $halfPoint);
        $specs['rightItems'] = array_slice($allItems, $halfPoint);

        // Fallback: Paragraphen als einzelne Spalte
        if (count($specs['leftItems']) === 0 && count($block['paragraphs']) > 0) {
            $specs['leftItems'] = $block['paragraphs'];
        }

        return (count($specs['leftItems']) > 0 || count($specs['rightItems']) > 0) ? $specs : null;
    }

    // =========================================================
    // Badges extrahieren
    // =========================================================

    private function extractBadges(string $html): array
    {
        $badges = [];

        // Aus <strong>-Tags kurze Phrasen extrahieren
        if (preg_match_all('/<strong>(.*?)<\/strong>/i', $html, $matches)) {
            foreach ($matches[1] as $raw) {
                $text = trim($this->stripHtml($raw));
                if (mb_strlen($text) >= 3 && mb_strlen($text) <= 40
                    && !str_contains($text, '.') && !str_ends_with($text, ':')) {
                    // Keine Duplikate, max 6
                    if (count($badges) < 6) {
                        $isDuplicate = false;
                        foreach ($badges as $b) {
                            if (mb_strtolower($b) === mb_strtolower($text)) {
                                $isDuplicate = true;
                                break;
                            }
                        }
                        if (!$isDuplicate) {
                            $badges[] = $text;
                        }
                    }
                }
            }
        }

        // Fallback: <li> mit <strong> am Anfang
        if (count($badges) < 3) {
            if (preg_match_all('/<li[^>]*>\s*<strong>(.*?)<\/strong>/i', $html, $matches)) {
                foreach ($matches[1] as $raw) {
                    $text = rtrim(trim($this->stripHtml($raw)), ':');
                    if (mb_strlen($text) >= 3 && mb_strlen($text) <= 40 && count($badges) < 6) {
                        $isDuplicate = false;
                        foreach ($badges as $b) {
                            if (mb_strtolower($b) === mb_strtolower($text)) {
                                $isDuplicate = true;
                                break;
                            }
                        }
                        if (!$isDuplicate) {
                            $badges[] = $text;
                        }
                    }
                }
            }
        }

        return $badges;
    }

    // =========================================================
    // Hilfsfunktionen
    // =========================================================

    private function matchesKeywords(string $titleLower, array $keywords): bool
    {
        foreach ($keywords as $kw) {
            if (str_contains($titleLower, $kw)) {
                return true;
            }
        }
        return false;
    }

    private function stripHtml(string $html): string
    {
        if (empty($html)) {
            return '';
        }
        $text = preg_replace('/<[^>]+>/', ' ', $html);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/', ' ', $text);
        return trim($text);
    }

    private function cleanTitle(string $title): string
    {
        return trim($this->stripHtml($title));
    }

    private function truncateToPhrase(string $text, int $maxLength): string
    {
        if (empty($text) || mb_strlen($text) <= $maxLength) {
            return $text;
        }

        $lastSpace = mb_strrpos(mb_substr($text, 0, $maxLength + 1), ' ');
        return $lastSpace > 0 ? mb_substr($text, 0, $lastSpace) : mb_substr($text, 0, $maxLength);
    }
}
