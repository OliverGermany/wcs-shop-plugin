<?php

/**
 * WCS Template Renderer
 *
 * Rendert ein HTML-Template mit strukturiertem Content und Farben.
 * PHP-Port des C# TemplateRenderer.cs - identische Logik.
 *
 * Platzhalter-Syntax:
 *   {{hero.title}}              - Einfacher Wert
 *   {{@sections}}...{{/@sections}} - Loop
 *   {{@.paragraphs}}...{{/@.paragraphs}} - Inner Loop
 *   {{#faq}}...{{/faq}}         - Conditional Block
 *   {{.title}}                  - Loop-Variable
 *   {{.}}                       - Aktueller Wert (Simple Loop)
 *   {{faq.jsonld}}              - FAQ JSON-LD Block
 *
 * @package WCS Structured Data
 * @version 1.5.0
 */

declare(strict_types=1);

namespace Plugin\wcsstructureddata;

class WcsTemplateRenderer
{
    /**
     * Rendert ein Layout-Template mit Content und Farben.
     *
     * @param string $templateHtml Das HTML-Template mit Platzhaltern
     * @param string $namespace    CSS-Namespace-Klasse (z.B. "wcs-elegant-cards")
     * @param array  $content      Strukturierter Content (aus WcsContentParser::parse())
     * @param array  $colors       Farb-Array ['accent'=>'#...', 'background'=>'#...', ...]
     * @param array  $fonts        Font-Array ['font_family'=>'...', 'size_h2'=>'...', ...] (optional)
     * @return string              Fertiges HTML
     */
    public function render(
        string $templateHtml,
        string $namespace,
        array $content,
        array $colors = [],
        array $fonts = []
    ): string {
        if (empty($templateHtml) || empty($content)) {
            return '';
        }

        $html = $templateHtml;

        // Schritt 0: Namespace + Farben einsetzen
        $html = str_replace('{{namespace}}', $namespace, $html);
        $html = $this->injectCssVariables($html, $namespace, $colors);

        // Font-Ueberschreibungen injizieren
        if (!empty($fonts)) {
            $fontCss = $this->buildFontCssOverrides($namespace, $fonts);
            if (!empty($fontCss)) {
                $styleEnd = stripos($html, '</style>');
                if ($styleEnd !== false) {
                    $html = substr($html, 0, $styleEnd) . "\n" . $fontCss . substr($html, $styleEnd);
                }
            }
        }

        // Duplikat-Check: Highlight-Text == erster Section-Absatz
        $highlight = $content['highlight'] ?? null;
        $sections = $content['sections'] ?? [];
        if ($highlight !== null && count($sections) > 0 && strpos($html, '{{#hero.highlight}}') !== false) {
            if (count($sections[0]['paragraphs'] ?? []) > 0
                && ($sections[0]['paragraphs'][0] ?? '') === ($highlight['text'] ?? '')) {
                array_shift($sections[0]['paragraphs']);
                if (count($sections[0]['paragraphs']) === 0
                    && count($sections[0]['listItems'] ?? []) === 0) {
                    array_shift($sections);
                }
                $content['sections'] = $sections;
            }
        }

        // Schritt 1: Sections-Loop
        $html = $this->processSectionsLoop($html, $content['sections'] ?? []);

        // Schritt 2: FAQ-Loop
        $html = $this->processFaqLoop($html, $content['faq'] ?? null);

        // Schritt 3: Badges-Loop
        $html = $this->processSimpleLoop($html, 'hero.badges', $content['badges'] ?? []);

        // Schritt 4: Tech-Specs
        $html = $this->processTechSpecs($html, $content['techSpecs'] ?? null);

        // Schritt 5: Conditional Blocks
        $html = $this->processConditionalBlocks($html, $content);

        // Schritt 6: Einfache Platzhalter
        $html = $this->replaceSimplePlaceholders($html, $content);

        // Schritt 7: FAQ JSON-LD
        $html = $this->processFaqJsonLd($html, $content['faq'] ?? null);

        // Schritt 8: Aufraeumen
        $html = $this->cleanupEmptyBlocks($html);

        // Schritt 9: FAQ-Interaktivitaet (onclick wird vom Sanitizer entfernt, daher hier per JS)
        if (!empty($content['faq']['items'])) {
            $html .= '<script>document.querySelectorAll(".faq-item").forEach(function(el){el.addEventListener("click",function(){this.classList.toggle("open")})});</script>';
        }

        return trim($html);
    }

    // =========================================================
    // CSS-Variablen einsetzen
    // =========================================================

    private function injectCssVariables(string $html, string $ns, array $colors): string
    {
        $accent     = $colors['accent'] ?? '#3cb54a';
        $background = $colors['background'] ?? '#f5f5f5';
        $heroBg     = $colors['hero_background'] ?? '#cdd8dc';
        $cardBg     = $colors['card_background'] ?? '#ffffff';
        $heading    = $colors['heading'] ?? '#102a43';
        $text       = $colors['text'] ?? '#253746';
        $border     = $colors['border'] ?? '#e1e8ed';

        $cssVars = ".{$ns} {\n"
            . "    --wcs-accent: {$accent};\n"
            . "    --wcs-bg: {$background};\n"
            . "    --wcs-hero-bg: {$heroBg};\n"
            . "    --wcs-card-bg: {$cardBg};\n"
            . "    --wcs-heading: {$heading};\n"
            . "    --wcs-text: {$text};\n"
            . "    --wcs-border: {$border};\n"
            . "}";

        $styleStart = stripos($html, '<style');
        if ($styleStart !== false) {
            $contentStart = strpos($html, '>', $styleStart);
            if ($contentStart !== false) {
                $contentStart++;
                $html = substr($html, 0, $contentStart) . "\n" . $cssVars . "\n" . substr($html, $contentStart);
            }
        }

        return $html;
    }

    // =========================================================
    // Font CSS Overrides
    // =========================================================

    private function buildFontCssOverrides(string $ns, array $fonts): string
    {
        $fontFamily = $fonts['font_family'] ?? '';
        $sizeH2    = $fonts['size_h2'] ?? '';
        $sizeH3    = $fonts['size_h3'] ?? '';
        $sizeP     = $fonts['size_p'] ?? '';

        if (empty($fontFamily) && empty($sizeH2) && empty($sizeH3) && empty($sizeP)) {
            return '';
        }

        $rules = '';
        if (!empty($fontFamily)) {
            $rules .= ".{$ns} { font-family: {$fontFamily}; }\n";
        }
        if (!empty($sizeH2)) {
            $rules .= ".{$ns} h2, .{$ns} .wcs-title { font-size: {$sizeH2}px !important; }\n";
        }
        if (!empty($sizeH3)) {
            $rules .= ".{$ns} h3, .{$ns} .wcs-section h2 { font-size: {$sizeH3}px !important; }\n";
        }
        if (!empty($sizeP)) {
            $rules .= ".{$ns} p, .{$ns} .wcs-section p, .{$ns} li, .{$ns} .wcs-list, .{$ns} .wcs-subtitle, .{$ns} .wcs-notice, .{$ns} .faq-question, .{$ns} .faq-answer { font-size: {$sizeP}px !important; }\n";
        }

        return $rules;
    }

    // =========================================================
    // Sections-Loop: {{@sections}}...{{/@sections}}
    // =========================================================

    private function processSectionsLoop(string $html, array $sections): string
    {
        $pattern = '/\{\{@sections\}\}(.*?)\{\{\/@sections\}\}/s';

        if (!preg_match($pattern, $html, $match) || count($sections) === 0) {
            return preg_replace($pattern, '', $html);
        }

        $template = $match[1];
        $output = '';

        foreach ($sections as $section) {
            $block = $template;

            // Titel
            $block = str_replace('{{.title}}', $this->escapeHtml($section['title'] ?? ''), $block);

            // Paragraphen-Loop
            $block = $this->processInnerLoop($block, '.paragraphs', $section['paragraphs'] ?? [], true);

            // Listen-Items-Loop
            $block = $this->processInnerLoop($block, '.list_items', $section['listItems'] ?? [], true);

            // Inner Conditionals
            $block = $this->processInnerConditional($block, '.paragraphs',
                !empty($section['paragraphs']));
            $block = $this->processInnerConditional($block, '.list_items',
                !empty($section['listItems']));

            $output .= $block;
        }

        return substr($html, 0, $match[0] !== '' ? strpos($html, $match[0]) : 0)
            . $output
            . substr($html, strpos($html, $match[0]) + strlen($match[0]));
    }

    // =========================================================
    // FAQ-Loop: {{@faq.items}}...{{/@faq.items}}
    // =========================================================

    private function processFaqLoop(string $html, ?array $faq): string
    {
        $pattern = '/\{\{@faq\.items\}\}(.*?)\{\{\/@faq\.items\}\}/s';

        $items = $faq['items'] ?? [];
        if (!preg_match($pattern, $html, $match) || count($items) === 0) {
            return preg_replace($pattern, '', $html);
        }

        $template = $match[1];
        $output = '';

        foreach ($items as $item) {
            $block = $template;
            $block = str_replace('{{.question}}', $this->escapeHtml($item['question'] ?? ''), $block);
            $block = str_replace('{{.answer}}', $this->escapeHtml($item['answer'] ?? ''), $block);
            $output .= $block;
        }

        $pos = strpos($html, $match[0]);
        return substr($html, 0, $pos) . $output . substr($html, $pos + strlen($match[0]));
    }

    // =========================================================
    // Einfacher Loop: {{@key}}...{{/@key}} mit {{.}}
    // =========================================================

    private function processSimpleLoop(string $html, string $key, ?array $items): string
    {
        $escapedKey = preg_quote($key, '/');
        $pattern = '/\{\{@' . $escapedKey . '\}\}\s*(.*?)\s*\{\{\/@' . $escapedKey . '\}\}/s';

        if (!preg_match($pattern, $html, $match) || $items === null || count($items) === 0) {
            return preg_replace($pattern, '', $html);
        }

        $template = $match[1];
        $output = '';

        foreach ($items as $item) {
            $output .= str_replace('{{.}}', $this->escapeHtml($item), $template);
        }

        $pos = strpos($html, $match[0]);
        return substr($html, 0, $pos) . $output . substr($html, $pos + strlen($match[0]));
    }

    // =========================================================
    // Inner Loop (innerhalb eines Section-Templates)
    // =========================================================

    private function processInnerLoop(string $block, string $key, array $items, bool $allowHtml = false): string
    {
        $escapedKey = preg_quote($key, '/');
        $pattern = '/\{\{@' . $escapedKey . '\}\}\s*(.*?)\s*\{\{\/@' . $escapedKey . '\}\}/s';

        if (!preg_match($pattern, $block, $match) || count($items) === 0) {
            return preg_replace($pattern, '', $block);
        }

        $template = $match[1];
        $output = '';

        foreach ($items as $item) {
            $value = $allowHtml ? $this->sanitizeHtml($item) : $this->escapeHtml($item);
            $output .= str_replace('{{.}}', $value, $template);
        }

        $pos = strpos($block, $match[0]);
        return substr($block, 0, $pos) . $output . substr($block, $pos + strlen($match[0]));
    }

    // =========================================================
    // Inner Conditional: {{#.key}}...{{/.key}}
    // =========================================================

    private function processInnerConditional(string $block, string $key, bool $hasContent): string
    {
        $escapedKey = preg_quote($key, '/');
        $pattern = '/\{\{#' . $escapedKey . '\}\}\s*(.*?)\s*\{\{\/' . $escapedKey . '\}\}/s';

        if ($hasContent) {
            return preg_replace($pattern, '$1', $block);
        }

        return preg_replace($pattern, '', $block);
    }

    // =========================================================
    // Tech-Specs: 2-Spalten-Layout
    // =========================================================

    private function processTechSpecs(string $html, ?array $specs): string
    {
        if ($specs !== null) {
            $html = $this->processSimpleLoop($html, 'tech.left', $specs['leftItems'] ?? []);
            $html = $this->processSimpleLoop($html, 'tech.right', $specs['rightItems'] ?? []);
            $html = str_replace('{{tech.title}}', $this->escapeHtml($specs['title'] ?? ''), $html);
        } else {
            $html = $this->processSimpleLoop($html, 'tech.left', null);
            $html = $this->processSimpleLoop($html, 'tech.right', null);
            $html = str_replace('{{tech.title}}', '', $html);
        }

        return $html;
    }

    // =========================================================
    // Conditional Blocks: {{#block}}...{{/block}}
    // =========================================================

    private function processConditionalBlocks(string $html, array $content): string
    {
        // Hero-Tag
        $html = $this->processConditional($html, 'hero.tag', !empty($content['tag']));

        // Badges
        $html = $this->processConditional($html, 'hero.badges', !empty($content['badges']));

        // Highlight
        $html = $this->processConditional($html, 'hero.highlight', $content['highlight'] !== null);

        // FAQ
        $faq = $content['faq'] ?? null;
        $hasFaq = $faq !== null && !empty($faq['items']);
        $html = $this->processConditional($html, 'faq', $hasFaq);

        // FAQ JSON-LD
        $includeJsonLd = $hasFaq && ($faq['includeJsonLd'] ?? false);
        $html = $this->processConditional($html, 'faq.include_jsonld', $includeJsonLd);

        // Notice
        $html = $this->processConditional($html, 'notice', !empty($content['noticeText']));

        // Tech-Specs
        $html = $this->processConditional($html, 'tech', ($content['techSpecs'] ?? null) !== null);

        return $html;
    }

    private function processConditional(string $html, string $key, bool $show): string
    {
        $escapedKey = preg_quote($key, '/');
        $pattern = '/\{\{#' . $escapedKey . '\}\}\s*(.*?)\s*\{\{\/' . $escapedKey . '\}\}/s';

        if ($show) {
            return preg_replace($pattern, '$1', $html);
        }

        return preg_replace($pattern, '', $html);
    }

    // =========================================================
    // Einfache Platzhalter ersetzen
    // =========================================================

    private function replaceSimplePlaceholders(string $html, array $content): string
    {
        // Hero
        $html = str_replace('{{hero.tag}}', $this->escapeHtml($content['tag'] ?? ''), $html);
        $html = str_replace('{{hero.title}}', $this->escapeHtml($content['title'] ?? ''), $html);
        $html = str_replace('{{hero.subtitle}}', $this->sanitizeHtml($content['subtitle'] ?? ''), $html);

        // Highlight
        $highlight = $content['highlight'] ?? null;
        if ($highlight !== null) {
            $html = str_replace('{{hero.highlight.title}}', $this->escapeHtml($highlight['title'] ?? ''), $html);
            $html = str_replace('{{hero.highlight.text}}', $this->sanitizeHtml($highlight['text'] ?? ''), $html);
        }

        // FAQ-Titel
        $faq = $content['faq'] ?? null;
        if ($faq !== null) {
            $html = str_replace('{{faq.title}}', $this->escapeHtml($faq['title'] ?? ''), $html);
        }

        // Notice
        $html = str_replace('{{notice.title}}', $this->escapeHtml($content['noticeTitle'] ?? ''), $html);
        $html = str_replace('{{notice.text}}', $this->sanitizeHtml($content['noticeText'] ?? ''), $html);

        return $html;
    }

    // =========================================================
    // FAQ JSON-LD generieren
    // =========================================================

    private function processFaqJsonLd(string $html, ?array $faq): string
    {
        $placeholder = '{{faq.jsonld}}';
        if (strpos($html, $placeholder) === false) {
            return $html;
        }

        if ($faq === null || !($faq['includeJsonLd'] ?? false) || empty($faq['items'])) {
            return str_replace($placeholder, '', $html);
        }

        $items = $faq['items'];
        $jsonLd = "<script type=\"application/ld+json\">\n";
        $jsonLd .= "{\n";
        $jsonLd .= "  \"@context\": \"https://schema.org\",\n";
        $jsonLd .= "  \"@type\": \"FAQPage\",\n";
        $jsonLd .= "  \"mainEntity\": [\n";

        $count = count($items);
        for ($i = 0; $i < $count; $i++) {
            $comma = ($i < $count - 1) ? ',' : '';
            $jsonLd .= "    {\n";
            $jsonLd .= "      \"@type\": \"Question\",\n";
            $jsonLd .= '      "name": ' . $this->jsonEscape($items[$i]['question'] ?? '') . ",\n";
            $jsonLd .= "      \"acceptedAnswer\": {\n";
            $jsonLd .= "        \"@type\": \"Answer\",\n";
            $jsonLd .= '        "text": ' . $this->jsonEscape($items[$i]['answer'] ?? '') . "\n";
            $jsonLd .= "      }\n";
            $jsonLd .= "    }" . $comma . "\n";
        }

        $jsonLd .= "  ]\n";
        $jsonLd .= "}\n";
        $jsonLd .= "</script>\n";

        return str_replace($placeholder, $jsonLd, $html);
    }

    // =========================================================
    // Aufraeumen
    // =========================================================

    private function cleanupEmptyBlocks(string $html): string
    {
        // Uebrig gebliebene Platzhalter entfernen
        $html = preg_replace('/\{\{[^}]+\}\}/', '', $html);

        // Leere Absaetze entfernen
        $html = preg_replace('/<p>\s*<\/p>/', '', $html);

        // Leere Listen entfernen
        $html = preg_replace('/<ul[^>]*>\s*<\/ul>/', '', $html);

        // Mehrfache Leerzeilen auf eine reduzieren
        $html = preg_replace('/\n{3,}/', "\n\n", $html);

        return $html;
    }

    // =========================================================
    // HTML-Escaping & Sanitizing
    // =========================================================

    /**
     * Escaped alle HTML-Tags (fuer reine Texte wie Titel).
     */
    private function escapeHtml(string $text): string
    {
        if (empty($text)) {
            return '';
        }
        // Erst bestehende Entities dekodieren (z.B. &#228; -> ae)
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // Dann nur die noetigen Zeichen escapen (Umlaute bleiben als UTF-8)
        return str_replace(
            ['&', '<', '>', '"'],
            ['&amp;', '&lt;', '&gt;', '&quot;'],
            $text
        );
    }

    /**
     * Erlaubt nur sichere Inline-HTML-Tags: strong, em, br, a.
     * Alles andere wird escaped.
     */
    private function sanitizeHtml(string $text): string
    {
        if (empty($text)) {
            return '';
        }

        // Erlaubte Tags temporaer schuetzen
        $allowedTags = [
            '<strong>'  => '%%STRONG_OPEN%%',
            '</strong>' => '%%STRONG_CLOSE%%',
            '<em>'      => '%%EM_OPEN%%',
            '</em>'     => '%%EM_CLOSE%%',
            '<br>'      => '%%BR%%',
            '<br/>'     => '%%BR%%',
            '<br />'    => '%%BR%%',
        ];

        // <a href="..."> Links schuetzen
        $text = preg_replace('/<a\s+href="([^"]+)"([^>]*)>/i', '%%A_OPEN:$1:$2%%', $text);
        $text = str_replace('</a>', '%%A_CLOSE%%', $text);

        foreach ($allowedTags as $tag => $placeholder) {
            $text = str_ireplace($tag, $placeholder, $text);
        }

        // Entities dekodieren
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // HTML escapen
        $text = str_replace(
            ['&', '<', '>', '"'],
            ['&amp;', '&lt;', '&gt;', '&quot;'],
            $text
        );

        // Geschuetzte Tags wiederherstellen
        foreach ($allowedTags as $tag => $placeholder) {
            $text = str_replace($placeholder, $tag, $text);
        }

        // Links wiederherstellen mit rel="noopener" target="_blank"
        $text = preg_replace(
            '/%%A_OPEN:([^:]+):([^%]*)%%/',
            '<a href="$1" rel="noopener" target="_blank">',
            $text
        );
        $text = str_replace('%%A_CLOSE%%', '</a>', $text);

        return $text;
    }

    /**
     * JSON-String-Escaping fuer FAQ JSON-LD.
     */
    private function jsonEscape(string $text): string
    {
        if (empty($text)) {
            return '""';
        }

        // HTML-Tags entfernen fuer JSON-LD
        $plain = preg_replace('/<[^>]+>/', '', $text);
        // HTML-Entities dekodieren
        $plain = html_entity_decode($plain, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // JSON-String escapen
        return '"' . str_replace(
            ['\\', '"', "\n", "\r", "\t"],
            ['\\\\', '\\"', '\\n', '\\r', '\\t'],
            $plain
        ) . '"';
    }
}
