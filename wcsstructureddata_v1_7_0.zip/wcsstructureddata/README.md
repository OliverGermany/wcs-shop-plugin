# WCS Structured Data für JTL-Shop 5

Optimiert Ihren JTL-Shop für Suchmaschinen und Social Media durch strukturierte Daten.

## Features

### Schema.org JSON-LD

- **Product Schema** - Vollständige Produktdaten für Google Rich Results
  - Name, Beschreibung, URL
  - SKU, GTIN/EAN (GTIN8, GTIN12, GTIN13, GTIN14), MPN
  - Marke/Hersteller
  - Produktbilder
  - Preis, Währung, Verfügbarkeit
  - Artikelzustand
  - Verkäufer (Organization)
  - Preisgültigkeit

- **BreadcrumbList Schema** - Navigationspfad für bessere Darstellung in Suchergebnissen
  - Automatische Duplikat-Erkennung
  - Korrekte Hierarchie (Startseite → Kategorien → Produkt)

- **AggregateRating** - Produktbewertungen für Sterneanzeige in Google
  - Durchschnittsbewertung
  - Anzahl Bewertungen

- **FAQ Schema** - FAQ-Bereich als strukturierte Daten für Google
  - Automatische Erkennung per Marker oder Überschriften
  - Duplikat-Handling konfigurierbar
  - Min. 2, max. 6 FAQ-Einträge

### OpenGraph Meta-Tags

- Optimierte Darstellung beim Teilen auf Facebook, LinkedIn, etc.
- og:type wird von "website" auf "product" korrigiert
- Vollständige Produktinformationen:
  - og:title, og:description, og:image, og:url
  - product:price:amount, product:price:currency
  - product:availability, product:brand

## Installation

1. ZIP-Datei über JTL-Shop Backend hochladen (Plugins → Pluginverwaltung → Upload)
2. Plugin installieren
3. Plugin aktivieren
4. Einstellungen nach Bedarf anpassen

## Einstellungen

| Einstellung | Beschreibung | Standard |
|-------------|--------------|----------|
| Plugin aktivieren | Gesamtes Plugin an/aus | An |
| Datenformat | JSON-LD (empfohlen): Entfernt Template-Microdata und ersetzt durch sauberes JSON-LD. Microdata: Nutzt die nativen Template-Daten ohne Aenderung. | JSON-LD |
| Product Schema | Schema.org Product-Daten auf Produktseiten ausgeben | An |
| Breadcrumb Schema | Schema.org BreadcrumbList auf Produktseiten ausgeben | An |
| Bewertungen (aggregateRating) | Bewertungen ausgeben wenn vorhanden | An |
| FAQ Schema aktivieren | FAQ aus Produktbeschreibung ausgeben | An |
| FAQ Duplikat-Handling | Bei doppelten Fragen: erste behalten (skip) oder letzte behalten (override) | skip |
| OpenGraph og:type=product | og:type von website auf product aendern | An |
| Debug-Modus | Logging in /jtllogs/wcs_structured_data.log | Aus |

## FAQ Schema - Dokumentation

Das Plugin erkennt FAQ-Bereiche in der Produktbeschreibung automatisch.

### Methode 1: WCS-Marker (empfohlen)

Umschließen Sie den FAQ-Bereich mit Markern:

```html
<!--WCS_FAQ_START-->
<h2>Fragen und Antworten</h2>
<h3>Wie lang ist die Lieferzeit?</h3>
<p>Die Lieferzeit beträgt 2-3 Werktage.</p>
<h3>Gibt es Garantie?</h3>
<p>Ja, 2 Jahre gesetzliche Gewährleistung.</p>
<!--WCS_FAQ_END-->
```

### Methode 2: H2-Überschriften (Fallback)

Ohne Marker sucht das Plugin nach H2-Überschriften mit folgenden Texten:
- FAQ
- Fragen und Antworten
- Fragen
- Häufige Fragen

### Aufbau

- **H3** = Frage
- **Inhalt nach H3** (bis zum nächsten H3) = Antwort
- Minimum: 2 FAQ-Einträge
- Maximum: 6 FAQ-Einträge

### Duplikat-Handling

Falls dieselbe Frage mehrfach vorkommt:
- **skip** (Standard): Erste Frage wird behalten
- **override**: Letzte Frage überschreibt vorherige

## Systemvoraussetzungen

- JTL-Shop 5.0.0 oder höher
- PHP 7.4 oder höher

## Validierung

Prüfen Sie die strukturierten Daten mit:
- [Google Rich Results Test](https://search.google.com/test/rich-results)
- [Schema.org Validator](https://validator.schema.org/)
- [Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/)

## Debug-Modus

Bei aktiviertem Debug-Modus werden Informationen in folgende Datei geschrieben:
```
/jtllogs/wcs_structured_data.log
```

Enthält:
- Verarbeitete Produkte
- Gefundene FAQ-Einträge
- Fehler bei der Schema-Generierung

## Support

Bei Fragen oder Problemen:
- Website: https://wavi-suite.de
- E-Mail: support@wavi-suite.de

## Lizenz

Proprietär - Lizenzschlüssel erforderlich

## Changelog

### Version 1.7.0 (2026-03-17)
- Neu: Datenformat-Einstellung (JSON-LD / Microdata)
- Neu: JSON-LD Modus entfernt Template-Microdata automatisch und ersetzt durch sauberes JSON-LD
- Neu: Microdata Modus nutzt JTL-native Daten ohne Aenderung
- Fix: og:type=product funktioniert jetzt unabhaengig von OpenGraph Meta-Tags Einstellung
- Entfernt: Separate OpenGraph Meta-Tags Einstellung (redundant, JTL liefert OG-Tags nativ)
- Product Schema und Breadcrumb Schema sind jetzt standardmaessig AN (fuer JSON-LD Modus)

### Version 1.6.5 (2026-03-16)
- Neu: Blog-Beiträge nachträglich aktualisieren (`?wcs_api=blog_update`)
- Neu: Text, Bild, SEO-Daten und Kategorie können nach Veröffentlichung geändert werden
- Neu: Altes Vorschaubild wird beim Update automatisch gelöscht

### Version 1.6.4 (2026-03-15)
- Fix: JSON-LD Product Schema ist jetzt standardmäßig deaktiviert (verhindert doppelte Schema-Ausgabe bei Themes mit eigenem Product Schema)
- Neu: Blog-Kategorien API-Endpoint (`?wcs_api=blog_categories`) für dynamisches Laden im Content-Planer
- Neu: Blog-Vorschaubild-Upload via API (Base64)

### Version 1.6.0 (2026-03-14)
- Neu: Blog-Erstellung über API-Endpoint (`?wcs_api=blog_create`)
- Neu: Authentifizierung via E-Mail + Auth-Code
- Neu: FAQ Schema mit automatischer Erkennung (WCS-Marker + H2-Fallback)
- Neu: FAQ Duplikat-Handling Einstellung (skip/override)
- Neu: OpenGraph Tag-Ersetzung (og:type website → product)
- Verbessert: Defensive Fehlerbehandlung in allen Schema-Generatoren

### Version 1.4.23 (2025-02-15)
- Verbessert: Stabilität und Performance
- Bugfix: Diverse Korrekturen

### Version 1.2.8 (2025-01-03)
- Entfernt: FAQ bei Varianten Einstellung (nicht praktikabel)
- Aufgeräumt: Debug-Code für Varianten entfernt

### Version 1.2.6 (2025-01-03)
- Neu: FAQ Schema (FAQPage)
- Neu: FAQ Duplikat-Handling Einstellung
- Neu: Automatische FAQ-Erkennung per WCS-Marker
- Neu: Fallback FAQ-Erkennung per H2-Whitelist

### Version 1.1.5 (2025-01-02)
- Bugfix: 500-Fehler bei Artikeln ohne FAQ behoben
- Verbessert: Defensive Programmierung mit try-catch

### Version 1.1.3 (2025-01-01)
- Initiale Store-Version
- Product Schema (JSON-LD)
- BreadcrumbList Schema (JSON-LD)
- OpenGraph Tag-Optimierung
- Bewertungen (aggregateRating)
- Konfigurierbare Einstellungen
- Debug-Modus

---

Entwickelt von [WAVI Creator Suite](https://wavi-suite.de)
