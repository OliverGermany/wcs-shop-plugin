<?php
/**
 * WCS Structured Data - License Admin Controller
 * 
 * @package WCS Structured Data
 * @version 1.3.1
 */

namespace Plugin\wcsstructureddata\adminmenu;

use JTL\Plugin\PluginInterface;
use JTL\Smarty\JTLSmarty;
use JTL\Shop;

class LicenseController
{
    private PluginInterface $plugin;
    private JTLSmarty $smarty;
    private string $licenseServerUrl = 'https://www.wawicreatorsuite.de/api/license.php';
    private string $licenseFile;
    
    public function __construct(PluginInterface $plugin, JTLSmarty $smarty)
    {
        $this->plugin = $plugin;
        $this->smarty = $smarty;
        $this->licenseFile = \PFAD_ROOT . 'jtllogs/wcs_license.json';
    }
    
    public function handle(): string
    {
        $action = $_POST['action'] ?? '';
        
        // Aktuelle Lizenzdaten laden
        $licenseData = $this->loadLicenseData();
        $licenseEmail = $licenseData['email'] ?? '';
        $licenseCode = $licenseData['code'] ?? '';
        $licenseValid = $licenseData['license_valid'] ?? false;
        $licenseName = $licenseData['customer_name'] ?? '';
        
        $successMessage = '';
        $errorMessage = '';
        
        // Prüfen ob Cache abgelaufen - dann neu prüfen
        if ($licenseValid && isset($licenseData['valid_until']) && $licenseData['valid_until'] < time()) {
            $result = $this->checkLicenseOnServer($licenseEmail, $licenseCode);
            $licenseValid = $result['success'] && ($result['license_valid'] ?? false);
            $licenseName = $result['customer_name'] ?? '';
            $this->saveLicenseData($licenseEmail, $licenseCode, $licenseValid, $licenseName);
        }
        
        // Aktion verarbeiten
        if ($action === 'check_license' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $newEmail = trim($_POST['wcs_license_email'] ?? '');
            $newCode = trim($_POST['wcs_license_code'] ?? '');
            
            if (empty($newEmail) || empty($newCode)) {
                $errorMessage = 'Bitte geben Sie E-Mail und Lizenzcode ein.';
            } else {
                // Lizenz prüfen
                $result = $this->checkLicenseOnServer($newEmail, $newCode);
                
                if ($result['success'] && $result['license_valid']) {
                    $licenseEmail = $newEmail;
                    $licenseCode = $newCode;
                    $licenseValid = true;
                    $licenseName = $result['customer_name'] ?? '';
                    $successMessage = 'Lizenz erfolgreich aktiviert!';
                    
                    $this->saveLicenseData($licenseEmail, $licenseCode, true, $licenseName);
                } else {
                    $errorMessage = $result['error'] ?? 'Lizenz ungültig oder kein aktives Abo gefunden.';
                    $licenseValid = false;
                    
                    $this->saveLicenseData($newEmail, $newCode, false, '');
                }
            }
        } elseif ($action === 'deactivate_license' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            // Lizenz deaktivieren
            $licenseEmail = '';
            $licenseCode = '';
            $licenseValid = false;
            $licenseName = '';
            $successMessage = 'Lizenz wurde deaktiviert.';
            
            // Lizenzdatei löschen
            if (file_exists($this->licenseFile)) {
                @unlink($this->licenseFile);
            }
        }
        
        // Template-Variablen
        $this->smarty->assign('licenseValid', $licenseValid);
        $this->smarty->assign('licenseEmail', $licenseEmail);
        $this->smarty->assign('licenseCode', $licenseCode);
        $this->smarty->assign('licenseName', $licenseName);
        $this->smarty->assign('successMessage', $successMessage);
        $this->smarty->assign('errorMessage', $errorMessage);
        $this->smarty->assign('adminUrl', Shop::getAdminURL() . '/plugin.php?kPlugin=' . $this->plugin->getID());

        // Design-Status
        $designStatus = $this->loadDesignStatus();
        $this->smarty->assign('designActive', $designStatus['active']);
        $this->smarty->assign('designTemplateId', $designStatus['template_id']);
        $this->smarty->assign('designUpdatedAt', $designStatus['updated_at']);
        
        return $this->smarty->fetch($this->plugin->getPaths()->getAdminPath() . 'templates/license.tpl');
    }
    
    private function checkLicenseOnServer(string $email, string $code): array
    {
        $domain = $_SERVER['HTTP_HOST'] ?? '';
        
        $postData = [
            'email' => $email,
            'license_code' => $code,
            'product' => 'wcs_structured_data',
            'domain' => $domain
        ];
        
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->licenseServerUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 && $response) {
                return json_decode($response, true) ?: ['success' => false, 'error' => 'Ungültige Server-Antwort'];
            }
            
            return ['success' => false, 'error' => 'Server nicht erreichbar (HTTP ' . $httpCode . ')'];
            
        } catch (\Throwable $e) {
            return ['success' => false, 'error' => 'Verbindungsfehler: ' . $e->getMessage()];
        }
    }
    
    private function saveLicenseData(string $email, string $code, bool $valid, string $customerName): void
    {
        $data = [
            'email' => $email,
            'code' => $code,
            'license_valid' => $valid,
            'customer_name' => $customerName,
            'valid_until' => time() + 86400, // 24 Stunden
            'checked_at' => date('Y-m-d H:i:s')
        ];
        @file_put_contents($this->licenseFile, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    private function loadLicenseData(): array
    {
        if (!file_exists($this->licenseFile)) {
            return [];
        }

        $data = json_decode(file_get_contents($this->licenseFile), true);
        return $data ?: [];
    }

    private function loadDesignStatus(): array
    {
        $configFile = \PFAD_ROOT . 'jtllogs/wcs_design_config.json';

        if (!file_exists($configFile)) {
            return ['active' => false, 'template_id' => '', 'updated_at' => ''];
        }

        $data = json_decode(file_get_contents($configFile), true);
        if (!$data || !is_array($data)) {
            return ['active' => false, 'template_id' => '', 'updated_at' => ''];
        }

        return [
            'active'      => true,
            'template_id' => $data['template_id'] ?? 'unbekannt',
            'updated_at'  => $data['updated_at'] ?? '',
        ];
    }
}
