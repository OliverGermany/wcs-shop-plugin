<?php
/**
 * WCS Structured Data - Design-Artikel Admin
 */

use Plugin\wcsstructureddata\adminmenu\ArticlesController;

require_once __DIR__ . '/ArticlesController.php';

/** @var \JTL\Plugin\PluginInterface $plugin */
/** @var \JTL\Smarty\JTLSmarty $smarty */

$controller = new ArticlesController($plugin, $smarty);
echo $controller->handle();
