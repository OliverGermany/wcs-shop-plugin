<div class="card">
    <div class="card-header">
        <h3 class="card-title">WCS Design-Artikel</h3>
    </div>
    <div class="card-body">

        {if $successMessage}
            <div class="alert alert-success">{$successMessage}</div>
        {/if}
        {if $errorMessage}
            <div class="alert alert-danger">{$errorMessage}</div>
        {/if}

        <div class="row mb-3">
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body text-center py-2">
                        <strong>{$whitelistCount}</strong> Artikel auf Whitelist
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body text-center py-2">
                        <strong>{$blacklistCount}</strong> Artikel auf Blacklist
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-light">
                    <div class="card-body text-center py-2">
                        <small class="text-muted">Aktualisiert: {$updatedAt|default:'nie'}</small>
                    </div>
                </div>
            </div>
        </div>

        <p class="text-muted small">
            Die Whitelist wird von WCS Desktop gesendet. Nur Artikel auf der Whitelist erhalten das Design im Shop.
            Hier k&ouml;nnen Sie einzelne Artikel auf die Blacklist setzen, um das Design f&uuml;r diese zu deaktivieren.
        </p>

        {if $articles|count > 0}
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th style="width:80px">Art.Nr</th>
                        <th>Artikelname</th>
                        <th style="width:100px" class="text-center">Status</th>
                        <th style="width:180px" class="text-center">Aktion</th>
                    </tr>
                </thead>
                <tbody>
                    {foreach $articles as $article}
                        <tr{if $article.is_blacklisted} class="table-danger"{/if}>
                            <td><code>{$article.artNr|escape}</code></td>
                            <td>
                                {$article.name|escape}
                                <small class="text-muted">(ID: {$article.id})</small>
                            </td>
                            <td class="text-center">
                                {if $article.is_blacklisted}
                                    <span class="badge badge-danger">Blacklist</span>
                                {else}
                                    <span class="badge badge-success">Aktiv</span>
                                {/if}
                            </td>
                            <td class="text-center">
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="action" value="toggle_blacklist">
                                    <input type="hidden" name="article_id" value="{$article.id}">
                                    {if $article.is_blacklisted}
                                        <button type="submit" class="btn btn-sm btn-outline-success"
                                                title="Design wieder aktivieren">
                                            Aktivieren
                                        </button>
                                    {else}
                                        <button type="submit" class="btn btn-sm btn-outline-danger"
                                                title="Design deaktivieren">
                                            Blockieren
                                        </button>
                                    {/if}
                                </form>
                                <form method="post" style="display:inline; margin-left:4px">
                                    <input type="hidden" name="action" value="remove_from_whitelist">
                                    <input type="hidden" name="article_id" value="{$article.id}">
                                    <button type="submit" class="btn btn-sm btn-outline-secondary"
                                            title="Artikel komplett entfernen"
                                            onclick="return confirm('Artikel {$article.id} wirklich entfernen?')">
                                        Entfernen
                                    </button>
                                </form>
                            </td>
                        </tr>
                    {/foreach}
                </tbody>
            </table>
        {else}
            <div class="alert alert-info">
                Noch keine Design-Artikel vorhanden. Senden Sie Artikel &uuml;ber WCS Desktop an den Shop.
            </div>
        {/if}

    </div>
</div>
