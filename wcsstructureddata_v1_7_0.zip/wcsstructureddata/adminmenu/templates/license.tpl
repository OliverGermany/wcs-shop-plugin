<div class="card">
    <div class="card-header">
        <h3>WCS Structured Data - Lizenzierung</h3>
    </div>
    <div class="card-body">
        
        {* Lizenzstatus-Anzeige *}
        <div class="alert {if $licenseValid}alert-success{else}alert-danger{/if} mb-4">
            <h4>
                {if $licenseValid}
                    <i class="fa fa-check-circle"></i> Plugin ist aktiviert
                {else}
                    <i class="fa fa-times-circle"></i> Plugin ist nicht aktiviert
                {/if}
            </h4>
            {if $licenseValid}
                <p class="mb-0">Lizenziert für: <strong>{$licenseEmail}</strong></p>
                {if $licenseName}<p class="mb-0">Kunde: <strong>{$licenseName}</strong></p>{/if}
            {else}
                <p class="mb-0">Bitte geben Sie Ihre Lizenzdaten ein und klicken Sie auf "Lizenz aktivieren".</p>
            {/if}
        </div>
        
        {* Design-Status *}
        {if $licenseValid}
        <div class="card mb-4">
            <div class="card-body">
                <h5><i class="fa fa-paint-brush"></i> Design-Status</h5>
                {if $designActive}
                    <p class="mb-1">
                        <span class="badge bg-success">Aktiv</span>
                        Template: <strong>{$designTemplateId|escape:'html'}</strong>
                    </p>
                    {if $designUpdatedAt}
                        <p class="mb-0 text-muted" style="font-size:12px;">
                            Letztes Update: {$designUpdatedAt|escape:'html'}
                        </p>
                    {/if}
                {else}
                    <p class="mb-0 text-muted">
                        <span class="badge bg-secondary">Inaktiv</span>
                        Noch kein Design konfiguriert. Verwenden Sie die WCS Desktop-App, um ein Design zu uebertragen.
                    </p>
                {/if}
            </div>
        </div>
        {/if}

        {* Erfolgsmeldung *}
        {if $successMessage}
            <div class="alert alert-success">
                <i class="fa fa-check"></i> {$successMessage}
            </div>
        {/if}
        
        {* Fehlermeldung *}
        {if $errorMessage}
            <div class="alert alert-danger">
                <i class="fa fa-exclamation-triangle"></i> {$errorMessage}
            </div>
        {/if}
        
        {* Lizenz-Formular *}
        <form method="post" action="{$adminUrl}">
            {$jtl_token}
            <input type="hidden" name="action" value="check_license">
            
            <div class="form-group mb-3">
                <label for="wcs_license_email" class="form-label"><strong>E-Mail-Adresse</strong></label>
                <input type="email" 
                       class="form-control" 
                       id="wcs_license_email" 
                       name="wcs_license_email" 
                       value="{$licenseEmail|escape:'html'}" 
                       placeholder="ihre@email.de"
                       required>
                <small class="form-text text-muted">Die E-Mail-Adresse Ihres WAVI Creator Suite Kontos</small>
            </div>
            
            <div class="form-group mb-3">
                <label for="wcs_license_code" class="form-label"><strong>Lizenzcode (Stripe Kundennummer)</strong></label>
                <input type="text" 
                       class="form-control" 
                       id="wcs_license_code" 
                       name="wcs_license_code" 
                       value="{$licenseCode|escape:'html'}" 
                       placeholder="cus_XXXXXXXXXXXXXX"
                       required>
                <small class="form-text text-muted">Ihre Stripe Kundennummer (beginnt mit "cus_")</small>
            </div>
            
            <div class="mt-4">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fa fa-key"></i> Lizenz aktivieren
                </button>
                
                {if $licenseValid}
                    <button type="submit" name="action" value="deactivate_license" class="btn btn-outline-danger ms-2">
                        <i class="fa fa-times"></i> Lizenz deaktivieren
                    </button>
                {/if}
            </div>
        </form>
        
        {* Hilfe-Box *}
        <div class="card mt-4 bg-light">
            <div class="card-body">
                <h5><i class="fa fa-info-circle"></i> Hilfe</h5>
                <p>Sie finden Ihre Lizenzdaten in Ihrem WAVI Creator Suite Konto:</p>
                <ul>
                    <li><strong>E-Mail:</strong> Die E-Mail-Adresse mit der Sie sich registriert haben</li>
                    <li><strong>Lizenzcode:</strong> Ihre Stripe Kundennummer (z.B. cus_Qv4n3q7eLrGDXF)</li>
                </ul>
                <p class="mb-0">
                    <a href="https://www.wavicreatorsuite.de" target="_blank" class="btn btn-sm btn-outline-primary">
                        <i class="fa fa-external-link"></i> Zum WAVI Creator Suite Portal
                    </a>
                </p>
            </div>
        </div>
        
    </div>
</div>
