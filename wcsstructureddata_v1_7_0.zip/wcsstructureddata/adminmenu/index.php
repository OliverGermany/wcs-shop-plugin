<?php
/**
 * WCS Structured Data - Admin Entry Point
 */

use Plugin\wcsstructureddata\adminmenu\LicenseController;

require_once __DIR__ . '/LicenseController.php';

/** @var \JTL\Plugin\PluginInterface $plugin */
/** @var \JTL\Smarty\JTLSmarty $smarty */

$controller = new LicenseController($plugin, $smarty);
echo $controller->handle();
