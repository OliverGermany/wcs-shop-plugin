<?php
/**
 * WCS Structured Data - Design-Artikel Admin Controller
 *
 * Zeigt Whitelist/Blacklist der Design-Artikel und ermöglicht Blacklist-Toggle.
 *
 * @package WCS Structured Data
 * @version 1.5.0
 */

namespace Plugin\wcsstructureddata\adminmenu;

use JTL\Plugin\PluginInterface;
use JTL\Smarty\JTLSmarty;
use JTL\Shop;

class ArticlesController
{
    private PluginInterface $plugin;
    private JTLSmarty $smarty;
    private string $articlesFile;

    public function __construct(PluginInterface $plugin, JTLSmarty $smarty)
    {
        $this->plugin = $plugin;
        $this->smarty = $smarty;
        $this->articlesFile = \PFAD_ROOT . 'jtllogs/wcs_design_articles.json';
    }

    public function handle(): string
    {
        $action = $_POST['action'] ?? '';
        $successMessage = '';
        $errorMessage = '';

        // POST-Actions verarbeiten
        if ($action === 'toggle_blacklist' && isset($_POST['article_id'])) {
            $articleId = (int)$_POST['article_id'];
            $data = $this->loadArticles();

            if (in_array($articleId, $data['blacklist'], true)) {
                // Von Blacklist entfernen
                $data['blacklist'] = array_values(array_diff($data['blacklist'], [$articleId]));
                $successMessage = "Artikel {$articleId} von Blacklist entfernt.";
            } else {
                // Auf Blacklist setzen
                $data['blacklist'][] = $articleId;
                $data['blacklist'] = array_values(array_unique($data['blacklist']));
                $successMessage = "Artikel {$articleId} auf Blacklist gesetzt.";
            }

            $data['updated_at'] = date('Y-m-d H:i:s');
            $this->saveArticles($data);
        }

        if ($action === 'remove_from_whitelist' && isset($_POST['article_id'])) {
            $articleId = (int)$_POST['article_id'];
            $data = $this->loadArticles();
            $data['whitelist'] = array_values(array_diff($data['whitelist'], [$articleId]));
            $data['blacklist'] = array_values(array_diff($data['blacklist'], [$articleId]));
            $data['updated_at'] = date('Y-m-d H:i:s');
            $this->saveArticles($data);
            $successMessage = "Artikel {$articleId} entfernt.";
        }

        // Artikeldaten laden
        $data = $this->loadArticles();
        $articles = $this->enrichWithNames($data['whitelist']);

        // Blacklist-Status zuweisen
        foreach ($articles as &$article) {
            $article['is_blacklisted'] = in_array($article['id'], $data['blacklist'], true);
        }
        unset($article);

        // Template-Variablen
        $this->smarty->assign('articles', $articles);
        $this->smarty->assign('whitelistCount', count($data['whitelist']));
        $this->smarty->assign('blacklistCount', count($data['blacklist']));
        $this->smarty->assign('updatedAt', $data['updated_at'] ?? '');
        $this->smarty->assign('successMessage', $successMessage);
        $this->smarty->assign('errorMessage', $errorMessage);

        return $this->smarty->fetch($this->plugin->getPaths()->getAdminPath() . 'templates/articles.tpl');
    }

    private function loadArticles(): array
    {
        $default = ['whitelist' => [], 'blacklist' => [], 'updated_at' => ''];

        if (!file_exists($this->articlesFile)) {
            return $default;
        }

        $data = json_decode(file_get_contents($this->articlesFile), true);
        if (!$data || !is_array($data)) {
            return $default;
        }

        return [
            'whitelist'  => array_map('intval', $data['whitelist'] ?? []),
            'blacklist'  => array_map('intval', $data['blacklist'] ?? []),
            'updated_at' => $data['updated_at'] ?? '',
        ];
    }

    private function saveArticles(array $data): bool
    {
        $json = json_encode($data, \JSON_PRETTY_PRINT | \JSON_UNESCAPED_UNICODE);
        return file_put_contents($this->articlesFile, $json) !== false;
    }

    /**
     * Lädt Artikelnamen aus der JTL-DB für die gegebenen IDs.
     */
    private function enrichWithNames(array $articleIds): array
    {
        $articles = [];

        if (empty($articleIds)) {
            return $articles;
        }

        try {
            $db = Shop::Container()->getDB();
            $placeholders = implode(',', array_map('intval', $articleIds));

            $rows = $db->getObjects(
                "SELECT a.kArtikel, a.cArtNr, ISNULL(ab.cName, a.cArtNr) AS cName
                 FROM tArtikel a
                 LEFT JOIN tArtikelBeschreibung ab ON ab.kArtikel = a.kArtikel AND ab.kSprache = 1 AND ab.kPlattform = 1 AND ab.kShop = 0
                 WHERE a.kArtikel IN ({$placeholders})"
            );

            $nameMap = [];
            foreach ($rows as $row) {
                $nameMap[(int)$row->kArtikel] = [
                    'artNr' => $row->cArtNr ?? '',
                    'name'  => $row->cName ?? '',
                ];
            }

            foreach ($articleIds as $id) {
                $info = $nameMap[$id] ?? null;
                $articles[] = [
                    'id'    => $id,
                    'artNr' => $info ? $info['artNr'] : '',
                    'name'  => $info ? $info['name'] : "(Artikel {$id})",
                ];
            }
        } catch (\Throwable $e) {
            // Fallback: IDs ohne Namen anzeigen
            foreach ($articleIds as $id) {
                $articles[] = [
                    'id'    => $id,
                    'artNr' => '',
                    'name'  => "(Artikel {$id})",
                ];
            }
        }

        return $articles;
    }
}
