<?php

/**
 * WCS Structured Data Plugin for JTL-Shop 5
 *
 * Strukturierte Daten (JSON-LD Schema.org, OpenGraph) fuer bessere SEO.
 * API-Endpoint fuer WCS Desktop Design-Konfiguration.
 *
 * @author WAVI Creator Suite
 * @copyright 2025 WAVI Creator Suite
 * @license MIT
 * @version 1.6.3
 *
 * Changelog v1.6.3:
 * - FIX: JSON-LD Product Schema standardmaessig deaktiviert (verhindert doppelte Schema-Ausgabe)
 *
 * Changelog v1.6.2:
 * - NEU: API-Endpoint fuer Blog-Kategorien (?wcs_api=blog_categories)
 * - NEU: App laedt Blog-Kategorien dynamisch vom Shop
 *
 * Changelog v1.6.1:
 * - NEU: Blog-Vorschaubild Unterstuetzung (Base64 Upload, Speicherung in media/image/news/)
 * - NEU: cPreviewImage wird in tnews gesetzt
 *
 * Changelog v1.6.0:
 * - NEU: Blog-Erstellung API (?wcs_api=blog_create)
 * - NEU: INSERT in tnews + tnewssprache + tseo + tnewskategorienews
 * - NEU: SEO-Slug Generierung mit Umlaut-Konvertierung und Duplikat-Check
 * - NEU: HTML-Sanitizing fuer Blog-Inhalte
 *
 * Changelog v1.5.0:
 * - NEU: API-Endpoint fuer Design-Konfiguration (?wcs_api=design)
 * - NEU: HTML-Sanitizing fuer template_html
 * - NEU: Rate-Limiting fuer API-Authentifizierung
 * - NEU: Design-Status in Admin-Seite
 * - NEU: Design-Rendering im OutputFilter (Parser + Renderer)
 * - NEU: Automatische FAQ-Schema-Duplikat-Vermeidung bei aktivem Design
 *
 * Changelog v1.4.23:
 * - Merkmal-Transformation entfernt (ob_start Konflikt mit BMS und anderen Plugins)
 * - Interne Verlinkung entfernt (wird extern geloest)
 * - Schlankerer Code, keine globalen Output-Buffer mehr
 */

declare(strict_types=1);

namespace Plugin\wcsstructureddata;

use JTL\Events\Dispatcher;
use JTL\Plugin\Bootstrapper;
use JTL\Shop;

class Bootstrap extends Bootstrapper
{
    private array $config = [];

    public function boot(Dispatcher $dispatcher): void
    {
        try {
            parent::boot($dispatcher);

            // API-Endpoints: Muss VOR isFrontend()-Check stehen
            if ($this->isApiRequest()) {
                if ($_GET['wcs_api'] === 'design_articles') {
                    $this->handleArticlesApiRequest();
                } elseif ($_GET['wcs_api'] === 'blog_create') {
                    $this->handleBlogCreateApiRequest();
                } elseif ($_GET['wcs_api'] === 'blog_update') {
                    $this->handleBlogUpdateApiRequest();
                } elseif ($_GET['wcs_api'] === 'blog_categories') {
                    $this->handleBlogCategoriesApiRequest();
                } else {
                    $this->handleApiRequest();
                }
                return;
            }

            if (!Shop::isFrontend()) {
                return;
            }

            $this->loadConfig();

            if ($this->config['wcs_active'] !== 'on') {
                return;
            }

            $dispatcher->listen('shop.hook.' . \HOOK_SMARTY_OUTPUTFILTER, function(array &$args) {
                $this->onOutputFilter($args);
            });
        } catch (\Throwable $e) {
            $this->logError('boot', $e);
        }
    }

    public function installed(): void
    {
        try {
            $this->logAlways('Plugin installed: v' . ($this->getPlugin()->getMeta()->getVersion() ?? '?'));
            parent::installed();
        } catch (\Throwable $e) {
            $this->logError('installed', $e);
            throw $e;
        }
    }

    public function uninstalled(bool $deleteData = true): void
    {
        try {
            $this->logAlways('Plugin uninstalled (deleteData=' . ($deleteData ? 'true' : 'false') . ')');
            parent::uninstalled($deleteData);

            $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
            if (file_exists($logFile) && $deleteData) {
                @unlink($logFile);
            }
        } catch (\Throwable $e) {
            $this->logError('uninstalled', $e);
            throw $e;
        }
    }

    public function updated($oldVersion, $newVersion): void
    {
        try {
            $this->logAlways("Plugin updated: v{$oldVersion} -> v{$newVersion}");
            parent::updated($oldVersion, $newVersion);
        } catch (\Throwable $e) {
            $this->logError('updated', $e);
            throw $e;
        }
    }

    private function loadConfig(): void
    {
        $plugin = $this->getPlugin();
        $config = $plugin->getConfig();
        
        $this->config = [
            'wcs_active'            => $config->getValue('wcs_active') ?? 'on',
            'wcs_data_format'       => $config->getValue('wcs_data_format') ?? 'jsonld',
            'wcs_product_schema'    => $config->getValue('wcs_product_schema') ?? 'on',
            'wcs_breadcrumb_schema' => $config->getValue('wcs_breadcrumb_schema') ?? 'on',
            'wcs_aggregate_rating'  => $config->getValue('wcs_aggregate_rating') ?? 'on',
            'wcs_faq_schema'        => $config->getValue('wcs_faq_schema') ?? 'on',
            'wcs_faq_duplicate'     => $config->getValue('wcs_faq_duplicate') ?? 'skip',
            'wcs_og_replace'        => $config->getValue('wcs_og_replace') ?? 'on',
            'wcs_debug'             => $config->getValue('wcs_debug') ?? '',
        ];
    }

    private function log(string $message): void
    {
        if ($this->config['wcs_debug'] !== 'on' && !empty($this->config)) {
            return;
        }

        $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
        $timestamp = date('Y-m-d H:i:s');
        @file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
    }

    /**
     * Schreibt IMMER ins Log, unabhaengig von Debug-Einstellung.
     * Fuer Install/Update/Uninstall Events.
     */
    private function logAlways(string $message): void
    {
        $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
        $timestamp = date('Y-m-d H:i:s');
        @file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
    }

    /**
     * Schreibt Fehler IMMER ins Log mit Stacktrace.
     * Fuer Diagnose von 500-Fehlern bei Installation/Update.
     */
    private function logError(string $context, \Throwable $e): void
    {
        $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
        $timestamp = date('Y-m-d H:i:s');
        $msg = "[$timestamp] ERROR in {$context}: {$e->getMessage()}\n"
             . "[$timestamp]   File: {$e->getFile()}:{$e->getLine()}\n"
             . "[$timestamp]   PHP: " . PHP_VERSION . " | Shop: " . (defined('APPLICATION_VERSION') ? APPLICATION_VERSION : '?') . "\n"
             . "[$timestamp]   Trace: " . str_replace("\n", "\n[$timestamp]   ", $e->getTraceAsString()) . "\n";
        @file_put_contents($logFile, $msg, FILE_APPEND);
    }

    private function checkLicense(): bool
    {
        $licenseFile = \PFAD_ROOT . 'jtllogs/wcs_license.json';
        
        if (!file_exists($licenseFile)) {
            $this->log('License check: No license file found');
            return false;
        }
        
        $licenseData = json_decode(file_get_contents($licenseFile), true);
        
        if (!$licenseData) {
            $this->log('License check: Invalid license file');
            return false;
        }
        
        $isValid = $licenseData['license_valid'] ?? false;
        $validUntil = $licenseData['valid_until'] ?? 0;
        
        if ($validUntil < time()) {
            $email = $licenseData['email'] ?? '';
            $code = $licenseData['code'] ?? '';
            
            if (empty($email) || empty($code)) {
                $this->log('License check: No credentials in license file');
                return false;
            }
            
            $isValid = $this->verifyLicenseOnServer($email, $code);
            
            $licenseData['license_valid'] = $isValid;
            $licenseData['valid_until'] = time() + 86400;
            $licenseData['checked_at'] = date('Y-m-d H:i:s');
            @file_put_contents($licenseFile, json_encode($licenseData, JSON_PRETTY_PRINT));
        }
        
        $this->log('License check: ' . ($isValid ? 'VALID' : 'INVALID'));
        return $isValid;
    }
    
    private function verifyLicenseOnServer(string $email, string $code): bool
    {
        $licenseServerUrl = 'https://www.wavicreatorsuite.de/api/license.php';
        $domain = $_SERVER['HTTP_HOST'] ?? '';
        
        $postData = [
            'email'        => $email,
            'license_code' => $code,
            'product'      => 'wcs_structured_data',
            'domain'       => $domain,
        ];
        
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $licenseServerUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 && $response) {
                $result = json_decode($response, true);
                return $result['license_valid'] ?? false;
            }
            
            $this->log('License verify: Server error - HTTP ' . $httpCode);
            
        } catch (\Throwable $e) {
            $this->log('License verify: Exception - ' . $e->getMessage());
        }
        
        return false;
    }

    // =====================================================
    // HOOK: SMARTY OUTPUTFILTER
    // =====================================================

    public function onOutputFilter(array &$args): void
    {
        try {
            $smarty = $args['smarty'] ?? null;
            $document = $args['document'] ?? null;

            if ($smarty === null || $document === null) {
                $this->log('ERROR: smarty or document is NULL');
                return;
            }

            if (!$this->checkLicense()) {
                $this->log('License check failed - stopping');
                return;
            }

            $pageType = null;
            try {
                $pageType = Shop::getPageType();
            } catch (\Throwable $e) {
                $this->log('getPageType error: ' . $e->getMessage());
            }

            $this->log('PageType: ' . $pageType);

            $product = $smarty->getTemplateVars('Artikel');

            if ($product === null || empty($product->kArtikel)) {
                $this->log('No product found for PageType ' . $pageType);
                return;
            }

            $this->log('Processing product (PageType=' . $pageType . '): ' . ($product->cName ?? 'unknown'));

            // ── Design-Rendering: Beschreibung mit Layout-Template ersetzen ──
            $designApplied = false;
            try {
                $designApplied = $this->applyDesignRendering($document, $product);
            } catch (\Throwable $e) {
                $this->log('Design rendering ERROR: ' . $e->getMessage());
            }

            $shopUrl = rtrim(Shop::getURL(), '/');
            $shopName = Shop::getSettingValue(\CONF_GLOBAL, 'global_shopname') ?: 'Shop';

            $isJsonLd = ($this->config['wcs_data_format'] === 'jsonld');
            $this->log('Data format: ' . ($isJsonLd ? 'JSON-LD' : 'Microdata'));

            // Bei JSON-LD Modus: Template-Microdata entfernen
            if ($isJsonLd) {
                $this->removeMicrodata($document);
            }

            $html = '<!-- WCS Structured Data v1.7.0 START -->';

            // 1. Product Schema (nur im JSON-LD Modus)
            if ($isJsonLd && $this->config['wcs_product_schema'] === 'on') {
                $productSchema = $this->buildProductSchema($product, $shopUrl);
                $html .= '<script type="application/ld+json">' . json_encode($productSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
                $this->log('Product Schema added (JSON-LD)');
            }

            // 2. Breadcrumb Schema (nur im JSON-LD Modus)
            if ($isJsonLd && $this->config['wcs_breadcrumb_schema'] === 'on') {
                $breadcrumbSchema = $this->buildBreadcrumbSchema($product, $smarty, $shopUrl);
                if ($breadcrumbSchema !== null) {
                    $html .= '<script type="application/ld+json">' . json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
                    $this->log('Breadcrumb Schema added (JSON-LD)');
                }
            }

            // 3. FAQ Schema (immer als JSON-LD, nur wenn KEIN Design aktiv)
            if ($this->config['wcs_faq_schema'] === 'on' && !$designApplied) {
                try {
                    $faqSchema = $this->buildFaqSchema($product);
                    if ($faqSchema !== null) {
                        $html .= '<script type="application/ld+json">' . json_encode($faqSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
                        $this->log('FAQ Schema generated with ' . count($faqSchema['mainEntity']) . ' items');
                    }
                } catch (\Throwable $e) {
                    $this->log('FAQ Schema ERROR: ' . $e->getMessage());
                }
            } elseif ($designApplied) {
                $this->log('FAQ Schema: Skipped (Design-Template generates FAQ JSON-LD)');
            }

            $html .= '<!-- WCS Structured Data v1.7.0 END -->';

            $document->find('head')->append($html);
            $this->log('Structured data appended successfully');

            // 4. OpenGraph: og:type=product ersetzen
            if ($this->config['wcs_og_replace'] === 'on') {
                $document->find('meta[property="og:type"]')->remove();
                $document->find('head')->append('<meta property="og:type" content="product">');
                $this->log('OpenGraph og:type replaced to product');
            }

            // 5. OpenGraph Auto-Detect: fehlende OG-Tags ergaenzen
            $this->autoFillOpenGraphTags($document, $product, $shopUrl, $shopName);

        } catch (\Throwable $e) {
            $this->log('onOutputFilter FATAL: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        }
    }

    // =====================================================
    // MICRODATA ENTFERNUNG
    // =====================================================

    /**
     * Entfernt Template-Microdata (itemscope, itemtype, itemprop) aus dem HTML.
     * Wird im JSON-LD Modus aufgerufen um doppelte strukturierte Daten zu vermeiden.
     */
    private function removeMicrodata($document): void
    {
        $count = 0;

        // Alle Elemente mit itemscope/itemtype/itemprop finden und Attribute entfernen
        foreach ($document->find('[itemscope]') as $el) {
            $el->removeAttribute('itemscope');
            $el->removeAttribute('itemtype');
            $count++;
        }

        foreach ($document->find('[itemprop]') as $el) {
            $tagName = strtolower($el->getTag() ?? '');
            $itemprop = $el->getAttribute('itemprop') ?? '';

            // Meta-Tags mit itemprop komplett entfernen (sie tragen nur Microdata)
            // ABER: meta name="description" behalten (wird fuer SEO benoetigt)
            if ($tagName === 'meta' && !$el->getAttribute('name')) {
                $el->remove();
                $count++;
                continue;
            }

            // Bei link-Tags mit itemprop: entfernen wenn nur fuer Microdata (z.B. availability)
            if ($tagName === 'link' && $itemprop === 'availability') {
                $el->remove();
                $count++;
                continue;
            }

            $el->removeAttribute('itemprop');
            $count++;
        }

        // html-Tag: itemscope/itemtype entfernen (z.B. itemtype="schema.org/ItemPage")
        foreach ($document->find('html[itemtype]') as $el) {
            $el->removeAttribute('itemscope');
            $el->removeAttribute('itemtype');
        }

        $this->log('Microdata removed: ' . $count . ' elements processed');
    }

    // =====================================================
    // DESIGN RENDERING
    // =====================================================

    /**
     * Wendet das Design-Layout auf die Produktbeschreibung an.
     * Ersetzt den Plain-Text (H2+P+UL) durch das gerenderte Layout-Template.
     *
     * @return bool true wenn Design erfolgreich angewendet wurde
     */
    private function applyDesignRendering($document, $product): bool
    {
        $description = $product->cBeschreibung ?? '';
        if (empty(trim($description))) {
            $this->log('Design: No description to render');
            return false;
        }

        // Whitelist/Blacklist prüfen
        $articleId = (int)($product->kArtikel ?? 0);
        $articles = $this->loadDesignArticles();
        if (in_array($articleId, $articles['blacklist'], true)) {
            $this->log('Design: Article ' . $articleId . ' is blacklisted');
            return false;
        }
        if (!empty($articles['whitelist']) && !in_array($articleId, $articles['whitelist'], true)) {
            $this->log('Design: Article ' . $articleId . ' not on whitelist');
            return false;
        }

        // Design-Config laden
        $designConfig = $this->loadDesignConfig();
        if ($designConfig === null) {
            $this->log('Design: No design config found');
            return false;
        }

        $templateHtml = $designConfig['template_html'] ?? '';
        if (empty($templateHtml)) {
            $this->log('Design: No template_html in config');
            return false;
        }

        $this->log('Design: Rendering with template ' . ($designConfig['template_id'] ?? 'unknown'));

        // Kategorie ermitteln
        $kategorie = $this->getProductCategory($product);

        // 1. Beschreibung parsen
        $parser = new WcsContentParser();
        $content = $parser->parse(
            $description,
            $product->cName ?? '',
            $kategorie
        );

        // 2. Template rendern
        $renderer = new WcsTemplateRenderer();
        $namespace = $designConfig['namespace'] ?? 'wcs-layout';
        $colors = $this->mapColorsForRenderer($designConfig['colors'] ?? []);
        $fonts = $this->mapFontsForRenderer($designConfig['fonts'] ?? []);

        $renderedHtml = $renderer->render(
            $templateHtml,
            $namespace,
            $content,
            $colors,
            $fonts
        );

        if (empty(trim($renderedHtml))) {
            $this->log('Design: Renderer returned empty output');
            return false;
        }

        // 3. Beschreibung im DOM ersetzen
        $replaced = $this->replaceDescriptionInDom($document, $description, $renderedHtml);

        if ($replaced) {
            $this->log('Design: Successfully applied');
        } else {
            $this->log('Design: Could not find description container in DOM');
        }

        return $replaced;
    }

    /**
     * Ersetzt die Produktbeschreibung im HTML-DOM durch das gerenderte Design.
     * Versucht mehrere Selektoren (kompatibel mit verschiedenen JTL-Templates).
     */
    private function replaceDescriptionInDom($document, string $originalDesc, string $renderedHtml): bool
    {
        // Strategie 1: Bekannte JTL-Template-Selektoren fuer Beschreibungs-Container
        $selectors = [
            '.desc',
            '#tab-beschreibung',
            '#content-beschreibung',
            '.tab-pane[id*="beschreibung"]',
            '.product-description',
            '#description',
            '.tab-pane[id*="description"]',
        ];

        foreach ($selectors as $selector) {
            try {
                $element = $document->find($selector);
                if ($element->length > 0) {
                    $element->html($renderedHtml);
                    $this->log('Design: Replaced via selector "' . $selector . '"');
                    return true;
                }
            } catch (\Throwable $e) {
                // Selector nicht gefunden, weiter versuchen
            }
        }

        // Strategie 2: Fallback - per String-Replacement im HTML
        // Die Beschreibung wird als raw HTML in die Seite eingebettet.
        // Wir suchen den Anfang der Beschreibung und ersetzen den gesamten Block.
        try {
            // Ersten signifikanten Teil der Beschreibung als Marker nehmen
            $descTrimmed = trim($originalDesc);
            if (mb_strlen($descTrimmed) > 50) {
                // Ersten H2 oder P Tag finden
                if (preg_match('/<(h2|p)[^>]*>.*?<\/\1>/s', $descTrimmed, $firstTag)) {
                    $marker = $firstTag[0];
                    $outerHtml = $document->htmlOuter();
                    if (strpos($outerHtml, $marker) !== false) {
                        // Container-Element finden das die Beschreibung enthaelt
                        // Suche nach dem naechsten umschliessenden div/section/article
                        $pos = strpos($outerHtml, $marker);
                        // Rueckwaerts nach oeffnendem Container-Tag suchen
                        $before = substr($outerHtml, 0, $pos);
                        $lastDiv = strrpos($before, '<div');
                        if ($lastDiv !== false) {
                            // Wir haben den Container gefunden
                            // Den gesamten Beschreibungsinhalt ersetzen
                            $newHtml = str_replace($descTrimmed, $renderedHtml, $outerHtml);
                            if ($newHtml !== $outerHtml) {
                                $document->replaceWith($newHtml);
                                $this->log('Design: Replaced via string fallback');
                                return true;
                            }
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            $this->log('Design: String fallback error: ' . $e->getMessage());
        }

        return false;
    }

    /**
     * Laedt die Design-Konfiguration aus der JSON-Datei.
     */
    private function loadDesignConfig(): ?array
    {
        $configFile = \PFAD_ROOT . 'jtllogs/wcs_design_config.json';

        if (!file_exists($configFile)) {
            return null;
        }

        $data = json_decode(file_get_contents($configFile), true);
        if (!$data || !is_array($data)) {
            return null;
        }

        return $data;
    }

    /**
     * Ermittelt die Hauptkategorie des Produkts.
     */
    private function getProductCategory($product): string
    {
        // Kategoriepfad versuchen
        if (isset($product->oKategorie_arr) && is_array($product->oKategorie_arr)) {
            foreach ($product->oKategorie_arr as $kat) {
                if (is_object($kat) && !empty($kat->cName)) {
                    return $kat->cName;
                }
            }
        }

        // Einzelne Kategorie
        if (isset($product->Kategorie) && is_object($product->Kategorie) && !empty($product->Kategorie->cName)) {
            return $product->Kategorie->cName;
        }

        // Kategorietext
        if (!empty($product->cKategorie)) {
            return $product->cKategorie;
        }

        return '';
    }

    /**
     * Mapped Farben von API-Format (camelCase) auf Renderer-Format (snake_case).
     */
    private function mapColorsForRenderer(array $apiColors): array
    {
        return [
            'accent'          => $apiColors['accent'] ?? '#3cb54a',
            'background'      => $apiColors['background'] ?? '#f5f5f5',
            'hero_background' => $apiColors['heroBackground'] ?? '#cdd8dc',
            'card_background' => $apiColors['cardBackground'] ?? '#ffffff',
            'heading'         => $apiColors['heading'] ?? '#102a43',
            'text'            => $apiColors['text'] ?? '#253746',
            'border'          => $apiColors['border'] ?? '#e1e8ed',
        ];
    }

    /**
     * Mapped Fonts von API-Format (camelCase) auf Renderer-Format (snake_case).
     */
    private function mapFontsForRenderer(array $apiFonts): array
    {
        return [
            'font_family' => $apiFonts['fontFamily'] ?? '',
            'size_h2'     => $apiFonts['sizeH2'] ?? '',
            'size_h3'     => $apiFonts['sizeH3'] ?? '',
            'size_p'      => $apiFonts['sizeP'] ?? '',
        ];
    }

    // =====================================================
    // PRODUCT SCHEMA
    // =====================================================

    private function buildProductSchema($product, string $shopUrl): array
    {
        $schema = [
            '@context' => 'https://schema.org',
            '@type'    => 'Product',
            'name'     => $this->cleanText($product->cName ?? 'Unbekannt'),
        ];
        
        if (!empty($product->cURLFull)) {
            $schema['url'] = $product->cURLFull;
        }
        
        if (!empty($product->cKurzBeschreibung)) {
            $schema['description'] = $this->cleanText($product->cKurzBeschreibung, 5000, true);
        } elseif (!empty($product->cBeschreibung)) {
            $schema['description'] = $this->cleanText($product->cBeschreibung, 5000, true);
        }
        
        if (!empty($product->cArtNr)) {
            $schema['sku'] = $product->cArtNr;
        }
        
        if (!empty($product->cBarcode)) {
            $gtin = preg_replace('/[^0-9]/', '', $product->cBarcode);
            $schema['gtin'] = $gtin;
            
            $len = strlen($gtin);
            if ($len === 13) {
                $schema['gtin13'] = $gtin;
            } elseif ($len === 12) {
                $schema['gtin12'] = $gtin;
            } elseif ($len === 8) {
                $schema['gtin8'] = $gtin;
            } elseif ($len === 14) {
                $schema['gtin14'] = $gtin;
            }
        }
        
        if (!empty($product->cHAN)) {
            $schema['mpn'] = $product->cHAN;
        }
        
        if (!empty($product->cHersteller)) {
            $schema['brand'] = [
                '@type' => 'Brand',
                'name'  => $product->cHersteller,
            ];
        }
        
        $images = $this->getProductImages($product, $shopUrl);
        if (!empty($images)) {
            $schema['image'] = $images;
        }
        
        if (isset($product->Preise->fVKBrutto) && $product->Preise->fVKBrutto > 0) {
            $schema['offers'] = $this->buildOffers($product, $shopUrl);
        }
        
        if ($this->config['wcs_aggregate_rating'] === 'on') {
            $rating = $this->getAggregateRating($product);
            if ($rating !== null) {
                $schema['aggregateRating'] = $rating;
            }
        }
        
        $schema['itemCondition'] = 'https://schema.org/NewCondition';
        
        return $schema;
    }

    private function getProductImages($product, string $shopUrl): array
    {
        $images = [];
        
        if (!empty($product->Bilder) && is_array($product->Bilder)) {
            foreach ($product->Bilder as $bild) {
                $imgUrl = $bild->cURLGross ?? $bild->cURLNormal ?? null;
                if (!empty($imgUrl)) {
                    $images[] = $this->makeAbsoluteUrl($imgUrl, $shopUrl);
                }
            }
        }
        
        return $images;
    }

    private function buildOffers($product, string $shopUrl): array
    {
        $price = number_format((float)$product->Preise->fVKBrutto, 2, '.', '');
        $currency = $_SESSION['Waehrung']->cISO ?? 'EUR';
        
        $availability = 'https://schema.org/InStock';
        if (isset($product->fLagerbestand) && (float)$product->fLagerbestand <= 0) {
            if (($product->cLagerBeachten ?? '') === 'Y') {
                $availability = 'https://schema.org/OutOfStock';
            }
        }

        $offers = [
            '@type'         => 'Offer',
            'price'         => $price,
            'priceCurrency' => $currency,
            'availability'  => $availability,
            'url'           => $product->cURLFull ?? $shopUrl,
            'itemCondition' => 'https://schema.org/NewCondition',
        ];
        
        $shopName = Shop::getSettingValue(\CONF_GLOBAL, 'global_shopname') ?: 'Shop';
        $offers['seller'] = [
            '@type' => 'Organization',
            'name'  => $shopName,
        ];
        
        $offers['priceValidUntil'] = date('Y-m-d', strtotime('+30 days'));
        
        return $offers;
    }

    private function getAggregateRating($product): ?array
    {
        if (isset($product->Bewertungen) && 
            !empty($product->Bewertungen->nAnzahlSprache) && 
            $product->Bewertungen->nAnzahlSprache > 0) {
            
            return [
                '@type'       => 'AggregateRating',
                'ratingValue' => number_format(
                    (float)($product->Bewertungen->fDurchschnitt ?? $product->fDurchschnittsBewertung ?? 0), 
                    1, '.', ''
                ),
                'reviewCount' => (int)$product->Bewertungen->nAnzahlSprache,
                'bestRating'  => '5',
                'worstRating' => '1',
            ];
        }
        
        if (isset($product->fDurchschnittsBewertung) && 
            $product->fDurchschnittsBewertung > 0 && 
            isset($product->nAnzahlBewertungen) && 
            $product->nAnzahlBewertungen > 0) {
            
            return [
                '@type'       => 'AggregateRating',
                'ratingValue' => number_format((float)$product->fDurchschnittsBewertung, 1, '.', ''),
                'reviewCount' => (int)$product->nAnzahlBewertungen,
                'bestRating'  => '5',
                'worstRating' => '1',
            ];
        }
        
        return null;
    }

    // =====================================================
    // FAQ SCHEMA
    // =====================================================

    private function buildFaqSchema($product): ?array
    {
        $description = $product->cBeschreibung ?? '';
        
        if (empty($description)) {
            $this->log('FAQ: No description found');
            return null;
        }
        
        $faqContent = '';
        
        // Methode 1: Marker suchen
        if (preg_match('/<!--WCS_FAQ_START-->(.*?)<!--WCS_FAQ_END-->/s', $description, $matches)) {
            $faqContent = $matches[1];
            $this->log('FAQ: Found WCS markers');
        } else {
            // Methode 2: H2 Whitelist
            $whitelist = [
                'FAQ',
                'Fragen und Antworten',
                'Fragen',
                'Häufige Fragen',
            ];
            
            foreach ($whitelist as $heading) {
                $pattern = '/<h2[^>]*>\s*' . preg_quote($heading, '/') . '\s*<\/h2>/i';
                if (preg_match($pattern, $description, $match, PREG_OFFSET_MATCH)) {
                    $startPos = $match[0][1];
                    $afterH2 = substr($description, $startPos);
                    
                    if (preg_match('/<h2[^>]*>/i', $afterH2, $nextH2Match, PREG_OFFSET_MATCH, strlen($match[0][0]))) {
                        $faqContent = substr($afterH2, 0, $nextH2Match[0][1]);
                    } else {
                        $faqContent = $afterH2;
                    }
                    
                    $this->log('FAQ: Found H2 whitelist heading: ' . $heading);
                    break;
                }
            }
        }
        
        if (empty($faqContent)) {
            $this->log('FAQ: No FAQ content found');
            return null;
        }
        
        $duplicateMode = $this->config['wcs_faq_duplicate'] ?? 'skip';
        $faqItems = $this->extractFaqItems($faqContent, $duplicateMode);
        
        if (count($faqItems) < 2) {
            $this->log('FAQ: Less than 2 items found (' . count($faqItems) . ')');
            return null;
        }
        
        if (count($faqItems) > 6) {
            $faqItems = array_slice($faqItems, 0, 6);
            $this->log('FAQ: Limited to 6 items');
        }
        
        $mainEntity = [];
        foreach ($faqItems as $item) {
            $mainEntity[] = [
                '@type' => 'Question',
                'name'  => $item['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text'  => $item['answer'],
                ],
            ];
        }
        
        return [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => $mainEntity,
        ];
    }

    private function extractFaqItems(string $content, string $duplicateMode = 'skip'): array
    {
        $items = [];
        $usedQuestions = [];
        
        if (empty($content)) {
            return $items;
        }
        
        $pattern = '/<h3[^>]*>(.*?)<\/h3>(.*?)(?=<h3[^>]*>|$)/si';
        
        if (preg_match_all($pattern, $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                if (!isset($match[1]) || !isset($match[2])) {
                    continue;
                }
                
                $questionRaw = strip_tags($match[1]);
                $answerRaw = strip_tags($match[2]);
                
                if (!is_string($questionRaw) || !is_string($answerRaw)) {
                    continue;
                }
                
                $question = $this->cleanText($questionRaw);
                $answer = $this->cleanText($answerRaw, 0, true);
                
                if (empty($question) || empty($answer)) {
                    continue;
                }
                
                $questionLower = mb_strtolower($question);
                if (isset($usedQuestions[$questionLower])) {
                    if ($duplicateMode === 'override') {
                        $existingIndex = $usedQuestions[$questionLower];
                        $items[$existingIndex] = [
                            'question' => $question,
                            'answer'   => $answer,
                        ];
                        $this->log('FAQ: Overriding duplicate question: ' . $question);
                    } else {
                        $this->log('FAQ: Skipping duplicate question: ' . $question);
                    }
                    continue;
                }
                
                $usedQuestions[$questionLower] = count($items);
                $items[] = [
                    'question' => $question,
                    'answer'   => $answer,
                ];
            }
        }
        
        return $items;
    }

    // =====================================================
    // BREADCRUMB SCHEMA
    // =====================================================

    private function buildBreadcrumbSchema($product, $smarty, string $shopUrl): ?array
    {
        $items = [];
        $usedUrls = [];
        $usedNames = [];
        $pos = 1;
        
        $shopUrl = rtrim($shopUrl, '/');
        
        $items[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => 'Startseite',
            'item'     => $shopUrl,
        ];
        $usedUrls[$this->normalizeUrl($shopUrl)] = true;
        $usedNames['startseite'] = true;
        
        $categories = $this->extractCategories($product, $smarty, $shopUrl);
        
        $this->log('Extracted categories count: ' . count($categories));
        
        $productUrl = $this->normalizeUrl($product->cURLFull ?? '');
        $productNameLower = mb_strtolower($this->cleanText($product->cName ?? ''));
        
        foreach ($categories as $cat) {
            $catUrlNormalized = $this->normalizeUrl($cat['url']);
            $catNameLower = mb_strtolower($cat['name']);
            
            if (isset($usedUrls[$catUrlNormalized])) {
                continue;
            }
            if (isset($usedNames[$catNameLower])) {
                continue;
            }
            if ($catUrlNormalized === $productUrl) {
                continue;
            }
            if ($catNameLower === $productNameLower) {
                continue;
            }
            
            $items[] = [
                '@type'    => 'ListItem',
                'position' => $pos++,
                'name'     => $cat['name'],
                'item'     => rtrim($cat['url'], '/'),
            ];
            $usedUrls[$catUrlNormalized] = true;
            $usedNames[$catNameLower] = true;
        }
        
        $productName = $this->cleanText($product->cName ?? '');
        
        if (!empty($productName) && !empty($productUrl)) {
            if (!isset($usedUrls[$productUrl]) && !isset($usedNames[$productNameLower])) {
                $items[] = [
                    '@type'    => 'ListItem',
                    'position' => $pos,
                    'name'     => $productName,
                    'item'     => rtrim($product->cURLFull, '/'),
                ];
            }
        }
        
        if (count($items) < 2) {
            return null;
        }
        
        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $items,
        ];
    }

    private function normalizeUrl(string $url): string
    {
        $url = mb_strtolower(trim($url));
        $url = rtrim($url, '/');
        return $url;
    }

    private function extractCategories($product, $smarty, string $shopUrl): array
    {
        $categories = [];
        
        $breadcrumbs = $smarty->getTemplateVars('Brotnavi');
        if ($breadcrumbs !== null && is_iterable($breadcrumbs)) {
            foreach ($breadcrumbs as $crumb) {
                $name = null;
                $url = null;
                
                if (is_object($crumb)) {
                    $name = $crumb->cName ?? $crumb->name ?? $crumb->title ?? $crumb->cBeschreibung ?? null;
                    $url = $crumb->cURLFull ?? $crumb->cURL ?? $crumb->url ?? $crumb->cSeo ?? null;
                    
                    if (empty($url) && !empty($crumb->cSeo)) {
                        $url = $shopUrl . '/' . ltrim($crumb->cSeo, '/');
                    }
                } elseif (is_array($crumb)) {
                    $name = $crumb['cName'] ?? $crumb['name'] ?? null;
                    $url = $crumb['cURLFull'] ?? $crumb['cURL'] ?? null;
                }
                
                if (!empty($name) && !empty($url)) {
                    $categories[] = [
                        'name' => $this->cleanText($name),
                        'url'  => $this->makeAbsoluteUrl($url, $shopUrl),
                    ];
                }
            }
        }
        
        if (empty($categories) && isset($product->oKategorie_arr) && is_array($product->oKategorie_arr)) {
            foreach ($product->oKategorie_arr as $kat) {
                if (is_object($kat)) {
                    $name = $kat->cName ?? null;
                    $url = $kat->cURLFull ?? $kat->cURL ?? null;
                    
                    if (!empty($name) && !empty($url)) {
                        $categories[] = [
                            'name' => $this->cleanText($name),
                            'url'  => $this->makeAbsoluteUrl($url, $shopUrl),
                        ];
                    }
                }
            }
        }
        
        if (empty($categories) && isset($product->Kategorie) && is_object($product->Kategorie)) {
            $kat = $product->Kategorie;
            $name = $kat->cName ?? null;
            $url = $kat->cURLFull ?? $kat->cURL ?? null;
            
            if (!empty($name) && !empty($url)) {
                $categories[] = [
                    'name' => $this->cleanText($name),
                    'url'  => $this->makeAbsoluteUrl($url, $shopUrl),
                ];
            }
        }
        
        return $categories;
    }

    // =====================================================
    // OPENGRAPH
    // =====================================================

    /**
     * Ergaenzt fehlende OpenGraph-Tags automatisch.
     * Prueft ob og:title, og:description, og:image bereits vom Template geliefert werden.
     * Nur fehlende Tags werden hinzugefuegt.
     */
    private function autoFillOpenGraphTags($document, $product, string $shopUrl, string $shopName): void
    {
        $filled = [];

        // og:title
        if (count($document->find('meta[property="og:title"]')) === 0) {
            $productName = $this->cleanText($product->cName ?? '');
            if (!empty($productName)) {
                $document->find('head')->append('<meta property="og:title" content="' . htmlspecialchars($productName, ENT_QUOTES, 'UTF-8') . '">');
                $filled[] = 'og:title';
            }
        }

        // og:description
        if (count($document->find('meta[property="og:description"]')) === 0) {
            $description = '';
            if (!empty($product->cKurzBeschreibung)) {
                $description = $this->cleanText($product->cKurzBeschreibung, 300, true);
            } elseif (!empty($product->cBeschreibung)) {
                $description = $this->cleanText($product->cBeschreibung, 300, true);
            }
            if (!empty($description)) {
                $document->find('head')->append('<meta property="og:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">');
                $filled[] = 'og:description';
            }
        }

        // og:image
        if (count($document->find('meta[property="og:image"]')) === 0) {
            $images = $this->getProductImages($product, $shopUrl);
            if (!empty($images)) {
                $document->find('head')->append('<meta property="og:image" content="' . htmlspecialchars($images[0], ENT_QUOTES, 'UTF-8') . '">');
                $filled[] = 'og:image';
            }
        }

        // og:url
        if (count($document->find('meta[property="og:url"]')) === 0) {
            if (!empty($product->cURLFull)) {
                $document->find('head')->append('<meta property="og:url" content="' . htmlspecialchars($product->cURLFull, ENT_QUOTES, 'UTF-8') . '">');
                $filled[] = 'og:url';
            }
        }

        // og:site_name
        if (count($document->find('meta[property="og:site_name"]')) === 0) {
            $document->find('head')->append('<meta property="og:site_name" content="' . htmlspecialchars($shopName, ENT_QUOTES, 'UTF-8') . '">');
            $filled[] = 'og:site_name';
        }

        if (!empty($filled)) {
            $this->log('OpenGraph auto-filled missing tags: ' . implode(', ', $filled));
        } else {
            $this->log('OpenGraph: all tags already present (template provides them)');
        }
    }

    private function handleOpenGraphTags($document, $product, string $shopUrl, string $shopName): void
    {
        $productName = $this->cleanText($product->cName ?? '');
        
        $description = '';
        if (!empty($product->cKurzBeschreibung)) {
            $description = $this->cleanText($product->cKurzBeschreibung, 300, true);
        } elseif (!empty($product->cBeschreibung)) {
            $description = $this->cleanText($product->cBeschreibung, 300, true);
        }
        
        $images = $this->getProductImages($product, $shopUrl);
        $imageUrl = !empty($images) ? $images[0] : '';
        
        $document->find('meta[property="og:type"]')->remove();
        $document->find('head')->append('<meta property="og:type" content="product">');
        
        $document->find('meta[property="og:site_name"]')->remove();
        $document->find('head')->append('<meta property="og:site_name" content="' . htmlspecialchars($shopName, ENT_QUOTES, 'UTF-8') . '">');
        
        if (!empty($productName)) {
            $document->find('meta[property="og:title"]')->remove();
            $document->find('head')->append('<meta property="og:title" content="' . htmlspecialchars($productName, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (!empty($description)) {
            $document->find('meta[property="og:description"]')->remove();
            $document->find('head')->append('<meta property="og:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (!empty($product->cURLFull)) {
            $document->find('meta[property="og:url"]')->remove();
            $document->find('head')->append('<meta property="og:url" content="' . htmlspecialchars($product->cURLFull, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (!empty($imageUrl)) {
            $document->find('meta[property="og:image"]')->remove();
            $document->find('head')->append('<meta property="og:image" content="' . htmlspecialchars($imageUrl, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (isset($product->Preise->fVKBrutto) && $product->Preise->fVKBrutto > 0) {
            $price = number_format((float)$product->Preise->fVKBrutto, 2, '.', '');
            $currency = $_SESSION['Waehrung']->cISO ?? 'EUR';
            
            $document->find('meta[property="product:price:amount"]')->remove();
            $document->find('meta[property="product:price:currency"]')->remove();
            
            $document->find('head')->append('<meta property="product:price:amount" content="' . $price . '">');
            $document->find('head')->append('<meta property="product:price:currency" content="' . $currency . '">');
        }
        
        $availability = 'in stock';
        if (isset($product->fLagerbestand) && (float)$product->fLagerbestand <= 0) {
            if (($product->cLagerBeachten ?? '') === 'Y') {
                $availability = 'out of stock';
            }
        }
        $document->find('meta[property="product:availability"]')->remove();
        $document->find('head')->append('<meta property="product:availability" content="' . $availability . '">');
        
        if (!empty($product->cHersteller)) {
            $document->find('meta[property="product:brand"]')->remove();
            $document->find('head')->append('<meta property="product:brand" content="' . htmlspecialchars($product->cHersteller, ENT_QUOTES, 'UTF-8') . '">');
        }
    }

    // =====================================================
    // HILFSMETHODEN
    // =====================================================

    private function cleanText(string $text, int $maxLength = 0, bool $stripTags = false): string
    {
        if ($text === '' || $text === null) {
            return '';
        }
        
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        $patterns = [
            '/\bfuer\b/i'      => 'für',
            '/\bfrueher\b/i'   => 'früher',
            '/\baussen\b/i'    => 'außen',
            '/\bgrosse\b/i'    => 'große',
            '/\bgrosses\b/i'   => 'großes',
            '/\bgrossen\b/i'   => 'großen',
            '/\bweiss\b/i'     => 'weiß',
            '/\bheiss\b/i'     => 'heiß',
            '/\bHoehe\b/'      => 'Höhe',
            '/\bhoehe\b/'      => 'höhe',
            '/\bLaenge\b/'     => 'Länge',
            '/\blaenge\b/'     => 'länge',
            '/\bfuehrt\b/i'    => 'führt',
            '/\bkoennen\b/i'   => 'können',
            '/\bkoennte\b/i'   => 'könnte',
            '/\bmuessen\b/i'   => 'müssen',
            '/\bwaere\b/i'     => 'wäre',
            '/\bwaeren\b/i'    => 'wären',
            '/\bueber\b/i'     => 'über',
            '/\baehnlich\b/i'  => 'ähnlich',
            '/\bAenderung\b/'  => 'Änderung',
            '/\baenderung\b/'  => 'änderung',
            '/\bOeffnung\b/'   => 'Öffnung',
            '/\boeffnung\b/'   => 'öffnung',
        ];
        
        foreach ($patterns as $pattern => $replacement) {
            $result = preg_replace($pattern, $replacement, $text);
            if ($result !== null) {
                $text = $result;
            }
        }
        
        $replacements = [
            '/\bFuer\b/'    => 'Für',
            '/\bFrueher\b/' => 'Früher',
            '/\bAussen\b/'  => 'Außen',
            '/\bGrosse\b/'  => 'Große',
            '/\bGrosses\b/' => 'Großes',
            '/\bWeiss\b/'   => 'Weiß',
            '/\bHeiss\b/'   => 'Heiß',
            '/\bUeber\b/'   => 'Über',
        ];
        
        foreach ($replacements as $pattern => $replacement) {
            $result = preg_replace($pattern, $replacement, $text);
            if ($result !== null) {
                $text = $result;
            }
        }
        
        if ($stripTags) {
            $text = strip_tags($text);
        }
        
        $result = preg_replace('/\s+/', ' ', trim($text));
        if ($result !== null) {
            $text = $result;
        }
        
        if ($maxLength > 0 && mb_strlen($text) > $maxLength) {
            $text = mb_substr($text, 0, $maxLength - 3) . '...';
        }
        
        return $text;
    }

    private function makeAbsoluteUrl(string $url, string $shopUrl): string
    {
        if (strpos($url, 'http') === 0) {
            return $url;
        }
        return rtrim($shopUrl, '/') . '/' . ltrim($url, '/');
    }

    // =====================================================
    // WCS DESIGN API
    // =====================================================

    private function isApiRequest(): bool
    {
        return isset($_GET['wcs_api']) && in_array($_GET['wcs_api'], ['design', 'design_articles', 'blog_create', 'blog_update', 'blog_categories'], true);
    }

    private function handleApiRequest(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
            return;
        }

        if ($this->isRateLimited()) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Too many requests'], 429);
            return;
        }

        $rawBody = file_get_contents('php://input');
        $data = json_decode($rawBody, true);

        if (!$data || !is_array($data)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Invalid JSON'], 400);
            return;
        }

        $authEmail = trim($data['auth_email'] ?? '');
        $authCode = trim($data['auth_code'] ?? '');

        if (empty($authEmail) || empty($authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing credentials'], 401);
            return;
        }

        if (!$this->authenticateApiRequest($authEmail, $authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Authentication failed'], 401);
            return;
        }

        $templateId = trim($data['template_id'] ?? '');

        if (empty($templateId)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing template_id'], 400);
            return;
        }

        $namespace = trim($data['namespace'] ?? '');
        if (empty($namespace)) {
            $namespace = 'wcs-layout';
        }
        // Namespace: nur alphanumerisch und Bindestriche erlauben
        $namespace = preg_replace('/[^a-zA-Z0-9\-]/', '', $namespace);

        $sanitizedHtml = $this->sanitizeTemplateHtml($data['template_html'] ?? '');
        $colors = $this->validateColors($data['colors'] ?? []);
        $fonts = $this->validateFonts($data['fonts'] ?? []);

        $designConfig = [
            'template_id'   => $templateId,
            'namespace'     => $namespace,
            'template_html' => $sanitizedHtml,
            'colors'        => $colors,
            'fonts'         => $fonts,
            'updated_at'    => date('Y-m-d H:i:s'),
            'updated_by'    => $authEmail,
        ];

        if (!$this->saveDesignConfig($designConfig)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Failed to save config'], 500);
            return;
        }

        $this->logApi('Design config saved: template_id=' . $templateId);
        $this->sendJsonResponse([
            'success'     => true,
            'message'     => 'Design config saved',
            'template_id' => $templateId,
            'updated_at'  => $designConfig['updated_at'],
        ]);
    }

    // =====================================================
    // WCS DESIGN ARTICLES API (Whitelist/Blacklist)
    // =====================================================

    private function handleArticlesApiRequest(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
            return;
        }

        if ($this->isRateLimited()) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Too many requests'], 429);
            return;
        }

        $rawBody = file_get_contents('php://input');
        $data = json_decode($rawBody, true);

        if (!$data || !is_array($data)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Invalid JSON'], 400);
            return;
        }

        $authEmail = trim($data['auth_email'] ?? '');
        $authCode = trim($data['auth_code'] ?? '');

        if (empty($authEmail) || empty($authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing credentials'], 401);
            return;
        }

        if (!$this->authenticateApiRequest($authEmail, $authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Authentication failed'], 401);
            return;
        }

        $action = trim($data['action'] ?? '');
        $articleIds = $data['article_ids'] ?? [];

        if (!is_array($articleIds)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'article_ids must be an array'], 400);
            return;
        }

        // Nur Integer-IDs erlauben
        $articleIds = array_values(array_unique(array_map('intval', array_filter($articleIds, 'is_numeric'))));

        $articles = $this->loadDesignArticles();

        switch ($action) {
            case 'sync':
                // Komplette Whitelist ersetzen
                $articles['whitelist'] = $articleIds;
                break;

            case 'add':
                // Artikel zur Whitelist hinzufügen
                $articles['whitelist'] = array_values(array_unique(array_merge($articles['whitelist'], $articleIds)));
                break;

            case 'remove':
                // Artikel von Whitelist entfernen
                $articles['whitelist'] = array_values(array_diff($articles['whitelist'], $articleIds));
                break;

            case 'blacklist':
                // Artikel auf Blacklist setzen
                $articles['blacklist'] = array_values(array_unique(array_merge($articles['blacklist'], $articleIds)));
                break;

            case 'unblacklist':
                // Artikel von Blacklist entfernen
                $articles['blacklist'] = array_values(array_diff($articles['blacklist'], $articleIds));
                break;

            default:
                $this->sendJsonResponse(['success' => false, 'error' => 'Invalid action. Use: sync, add, remove, blacklist, unblacklist'], 400);
                return;
        }

        $articles['updated_at'] = date('Y-m-d H:i:s');

        if (!$this->saveDesignArticles($articles)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Failed to save articles config'], 500);
            return;
        }

        $this->logApi('Design articles updated: action=' . $action . ' count=' . count($articleIds));
        $this->sendJsonResponse([
            'success'        => true,
            'message'        => 'Articles updated',
            'action'         => $action,
            'whitelist_count' => count($articles['whitelist']),
            'blacklist_count' => count($articles['blacklist']),
        ]);
    }

    private function loadDesignArticles(): array
    {
        $configFile = \PFAD_ROOT . 'jtllogs/wcs_design_articles.json';
        $default = ['whitelist' => [], 'blacklist' => [], 'updated_at' => ''];

        if (!file_exists($configFile)) {
            return $default;
        }

        $data = json_decode(file_get_contents($configFile), true);
        if (!$data || !is_array($data)) {
            return $default;
        }

        return [
            'whitelist'  => array_map('intval', $data['whitelist'] ?? []),
            'blacklist'  => array_map('intval', $data['blacklist'] ?? []),
            'updated_at' => $data['updated_at'] ?? '',
        ];
    }

    private function saveDesignArticles(array $data): bool
    {
        $configFile = \PFAD_ROOT . 'jtllogs/wcs_design_articles.json';
        $json = json_encode($data, \JSON_PRETTY_PRINT | \JSON_UNESCAPED_UNICODE);
        return file_put_contents($configFile, $json) !== false;
    }

    private function authenticateApiRequest(string $email, string $code): bool
    {
        $licenseFile = \PFAD_ROOT . 'jtllogs/wcs_license.json';

        if (!file_exists($licenseFile)) {
            $this->logApi('Auth failed: No license file');
            return false;
        }

        $licenseData = json_decode(file_get_contents($licenseFile), true);
        if (!$licenseData) {
            $this->logApi('Auth failed: Invalid license file');
            return false;
        }

        $storedEmail = $licenseData['email'] ?? '';
        $storedCode = $licenseData['code'] ?? '';
        $isValid = $licenseData['license_valid'] ?? false;

        if (!$isValid) {
            $this->logApi('Auth failed: License not valid');
            return false;
        }

        if (mb_strtolower($email) !== mb_strtolower($storedEmail)) {
            $this->logApi('Auth failed: Email mismatch');
            return false;
        }

        if ($code !== $storedCode) {
            $this->logApi('Auth failed: Code mismatch');
            return false;
        }

        return true;
    }

    private function sanitizeTemplateHtml(string $html): string
    {
        if (empty($html)) {
            return '';
        }

        // <script>-Tags entfernen
        $html = preg_replace('/<script\b[^>]*>.*?<\/script>/is', '', $html);

        // Event-Handler (on*) entfernen
        $html = preg_replace('/\s+on\w+\s*=\s*(["\']).*?\1/i', '', $html);
        $html = preg_replace('/\s+on\w+\s*=\s*[^\s>]+/i', '', $html);

        // javascript: URLs entfernen
        $html = preg_replace('/href\s*=\s*(["\'])\s*javascript:.*?\1/i', 'href=$1#$1', $html);
        $html = preg_replace('/src\s*=\s*(["\'])\s*javascript:.*?\1/i', '', $html);

        // data: URLs in src entfernen
        $html = preg_replace('/src\s*=\s*(["\'])\s*data:.*?\1/i', '', $html);

        // Gefaehrliche Tags entfernen
        $html = preg_replace('/<(iframe|object|embed|form|input|textarea|button)\b[^>]*>.*?<\/\1>/is', '', $html);
        $html = preg_replace('/<(iframe|object|embed|form|input|textarea|button)\b[^>]*\/?>/i', '', $html);

        // CSS expression() und javascript: in style-Attributen
        $html = preg_replace('/style\s*=\s*(["\'])[^"\']*expression\s*\([^"\']*\1/i', '', $html);
        $html = preg_replace('/style\s*=\s*(["\'])[^"\']*javascript:[^"\']*\1/i', '', $html);

        return trim($html);
    }

    private function validateColors(array $input): array
    {
        $defaults = [
            'accent'         => '#3cb54a',
            'background'     => '#f5f5f5',
            'heroBackground' => '#cdd8dc',
            'cardBackground' => '#ffffff',
            'heading'        => '#102a43',
            'text'           => '#253746',
            'border'         => '#e1e8ed',
        ];

        $colors = [];
        foreach ($defaults as $key => $default) {
            $value = $input[$key] ?? $default;
            if (preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $value)) {
                $colors[$key] = $value;
            } else {
                $colors[$key] = $default;
            }
        }
        return $colors;
    }

    private function validateFonts(array $input): array
    {
        $allowedFonts = [
            '', 'Arial, Helvetica, sans-serif', 'Verdana, Geneva, sans-serif',
            'Tahoma, Geneva, sans-serif', 'Trebuchet MS, sans-serif',
            'Georgia, serif', 'Times New Roman, serif', 'Courier New, monospace',
            'Segoe UI, sans-serif', 'Roboto, sans-serif', 'Open Sans, sans-serif',
            'Lato, sans-serif', 'Montserrat, sans-serif', 'Poppins, sans-serif',
            'Inter, sans-serif',
        ];

        $fontFamily = $input['fontFamily'] ?? '';
        if (!in_array($fontFamily, $allowedFonts, true)) {
            $fontFamily = '';
        }

        $validateSize = function ($val) {
            $size = (int)($val ?? 0);
            return ($size >= 8 && $size <= 72) ? (string)$size : '';
        };

        return [
            'fontFamily' => $fontFamily,
            'sizeH2'     => $validateSize($input['sizeH2'] ?? ''),
            'sizeH3'     => $validateSize($input['sizeH3'] ?? ''),
            'sizeP'      => $validateSize($input['sizeP'] ?? ''),
        ];
    }

    private function saveDesignConfig(array $config): bool
    {
        $configFile = \PFAD_ROOT . 'jtllogs/wcs_design_config.json';
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($json === false) {
            $this->logApi('Failed to encode design config');
            return false;
        }

        $result = @file_put_contents($configFile, $json);

        if ($result === false) {
            $this->logApi('Failed to write design config to ' . $configFile);
            return false;
        }

        return true;
    }

    // =====================================================
    // API RATE LIMITING
    // =====================================================

    private function isRateLimited(): bool
    {
        $rateLimitFile = \PFAD_ROOT . 'jtllogs/wcs_api_ratelimit.json';

        if (!file_exists($rateLimitFile)) {
            return false;
        }

        $data = json_decode(file_get_contents($rateLimitFile), true);
        if (!$data || !is_array($data)) {
            return false;
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $windowStart = time() - 60;

        $attempts = $data[$ip] ?? [];
        $attempts = array_filter($attempts, fn($t) => $t > $windowStart);

        return count($attempts) >= 5;
    }

    private function recordFailedAuth(): void
    {
        $rateLimitFile = \PFAD_ROOT . 'jtllogs/wcs_api_ratelimit.json';

        $data = [];
        if (file_exists($rateLimitFile)) {
            $data = json_decode(file_get_contents($rateLimitFile), true) ?? [];
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $now = time();
        $windowStart = $now - 60;

        if (isset($data[$ip])) {
            $data[$ip] = array_values(array_filter($data[$ip], fn($t) => $t > $windowStart));
        } else {
            $data[$ip] = [];
        }

        $data[$ip][] = $now;

        // Alte IPs bereinigen (aelter als 5 Minuten)
        $cleanupWindow = $now - 300;
        foreach ($data as $ipKey => $attempts) {
            $data[$ipKey] = array_values(array_filter($attempts, fn($t) => $t > $cleanupWindow));
            if (empty($data[$ipKey])) {
                unset($data[$ipKey]);
            }
        }

        @file_put_contents($rateLimitFile, json_encode($data));
    }

    // =====================================================
    // API HILFSMETHODEN
    // =====================================================

    // =====================================================
    // WCS BLOG CREATE API
    // =====================================================

    private function handleBlogCategoriesApiRequest(): void
    {
        // Nur GET erlauben
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
            return;
        }

        // Rate-Limiting
        if ($this->isRateLimited()) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Too many requests'], 429);
            return;
        }

        // Authentifizierung via Query-Parameter
        $authEmail = trim($_GET['auth_email'] ?? '');
        $authCode = trim($_GET['auth_code'] ?? '');

        if (empty($authEmail) || empty($authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing credentials'], 401);
            return;
        }

        if (!$this->authenticateApiRequest($authEmail, $authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Authentication failed'], 401);
            return;
        }

        try {
            $db = Shop::Container()->getDB();
            $categories = $db->queryPrepared(
                "SELECT nk.kNewsKategorie, nks.cName
                 FROM tnewskategorie nk
                 JOIN tnewskategoriesprache nks ON nks.kNewsKategorie = nk.kNewsKategorie
                 WHERE nks.languageID = 1
                 ORDER BY nk.kNewsKategorie",
                [],
                2
            );

            $result = [];
            if ($categories && is_array($categories)) {
                foreach ($categories as $cat) {
                    $result[] = [
                        'id' => (int)$cat->kNewsKategorie,
                        'name' => $cat->cName
                    ];
                }
            }

            $this->sendJsonResponse(['success' => true, 'categories' => $result]);
        } catch (\Exception $e) {
            $this->logApi("Blog categories error: " . $e->getMessage());
            $this->sendJsonResponse(['success' => false, 'error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    private function handleBlogCreateApiRequest(): void
    {
        // Nur POST erlauben
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
            return;
        }

        // Rate-Limiting
        if ($this->isRateLimited()) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Too many requests'], 429);
            return;
        }

        // JSON-Body parsen
        $rawBody = file_get_contents('php://input');
        $data = json_decode($rawBody, true);

        if (!$data || !is_array($data)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Invalid JSON'], 400);
            return;
        }

        // Authentifizierung
        $authEmail = trim($data['auth_email'] ?? '');
        $authCode = trim($data['auth_code'] ?? '');

        if (empty($authEmail) || empty($authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing credentials'], 401);
            return;
        }

        if (!$this->authenticateApiRequest($authEmail, $authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Authentication failed'], 401);
            return;
        }

        // Pflichtfelder pruefen
        $title = trim($data['title'] ?? '');
        $htmlContent = $data['html_content'] ?? '';
        $seoSlug = trim($data['seo_slug'] ?? '');

        if (empty($title)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing field: title'], 400);
            return;
        }

        if (empty($htmlContent)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing field: html_content'], 400);
            return;
        }

        if (empty($seoSlug)) {
            $seoSlug = $this->sanitizeBlogSeoSlug($title);
        } else {
            $seoSlug = $this->sanitizeBlogSeoSlug($seoSlug);
        }

        // HTML sanitizen (erlaubte Blog-Tags)
        $allowedTags = '<h1><h2><h3><h4><h5><p><br><ul><ol><li><strong><em><a><img><table><tr><td><th><thead><tbody><blockquote><figure><figcaption>';
        $cleanHtml = strip_tags($htmlContent, $allowedTags);

        // Script/Event-Handler entfernen
        $cleanHtml = preg_replace('/\s+on\w+\s*=\s*"[^"]*"/i', '', $cleanHtml);
        $cleanHtml = preg_replace('/\s+on\w+\s*=\s*\'[^\']*\'/i', '', $cleanHtml);
        $cleanHtml = preg_replace('/href\s*=\s*"javascript:[^"]*"/i', '', $cleanHtml);

        // DB-Zugriff
        $db = Shop::Container()->getDB();

        // SEO-Slug Duplikat-Check
        $existing = $db->queryPrepared(
            "SELECT cSeo FROM tseo WHERE cSeo = :seo",
            ['seo' => $seoSlug],
            1
        );
        if ($existing) {
            $seoSlug .= '-' . time();
        }

        // Optionale Felder
        $previewText = htmlspecialchars(trim($data['preview_text'] ?? ''), ENT_QUOTES, 'UTF-8');
        $metaTitle = htmlspecialchars(trim($data['meta_title'] ?? $title), ENT_QUOTES, 'UTF-8');
        $metaDescription = htmlspecialchars(trim($data['meta_description'] ?? ''), ENT_QUOTES, 'UTF-8');
        $metaKeywords = htmlspecialchars(trim($data['meta_keywords'] ?? ''), ENT_QUOTES, 'UTF-8');
        $newsCategoryId = (int)($data['news_category_id'] ?? 1);
        $active = ($data['active'] ?? true) ? 1 : 0;
        $now = date('Y-m-d H:i:s');

        // Vorschaubild verarbeiten (Base64 -> Datei)
        $previewImagePath = '';
        $previewImageBase64 = trim($data['preview_image'] ?? '');
        if (!empty($previewImageBase64)) {
            try {
                $imageData = base64_decode($previewImageBase64, true);
                if ($imageData !== false && strlen($imageData) > 0) {
                    // Bildformat erkennen
                    $finfo = new \finfo(FILEINFO_MIME_TYPE);
                    $mimeType = $finfo->buffer($imageData);
                    $ext = 'jpg';
                    if ($mimeType === 'image/png') $ext = 'png';
                    elseif ($mimeType === 'image/webp') $ext = 'webp';
                    elseif ($mimeType === 'image/gif') $ext = 'gif';

                    // Dateiname generieren
                    $fileName = 'wcs_blog_' . $seoSlug . '_' . time() . '.' . $ext;

                    // Zielverzeichnis (JTL-Shop Medienordner)
                    $mediaDir = \PFAD_ROOT . 'media/image/news/';
                    if (!is_dir($mediaDir)) {
                        mkdir($mediaDir, 0755, true);
                    }

                    // Datei speichern
                    $filePath = $mediaDir . $fileName;
                    if (file_put_contents($filePath, $imageData) !== false) {
                        $previewImagePath = 'media/image/news/' . $fileName;
                        $this->logApi("Blog preview image saved: " . $previewImagePath);
                    }
                }
            } catch (\Exception $imgEx) {
                $this->logApi("Blog preview image error: " . $imgEx->getMessage());
                // Kein Abbruch - Beitrag wird ohne Bild erstellt
            }
        }

        // 1. INSERT INTO tnews (Basis-Eintrag: nur Struktur-Spalten)
        try {
            $db->queryPrepared(
                "INSERT INTO tnews (cKundengruppe, nAktiv, dErstellt, dGueltigVon, cPreviewImage)
                 VALUES (:kundengruppe, :aktiv, :erstellt, :gueltig, :previewImage)",
                [
                    'kundengruppe' => ';-1;',
                    'aktiv' => $active,
                    'erstellt' => $now,
                    'gueltig' => $now,
                    'previewImage' => $previewImagePath
                ],
                3
            );

            // ID ueber SELECT holen (zuverlaessiger als ReturnType)
            $result = $db->queryPrepared("SELECT LAST_INSERT_ID() as kNews", [], 1);
            $kNews = (int)($result->kNews ?? 0);
        } catch (\Exception $e) {
            $this->logApi("Blog create SQL error: " . $e->getMessage());
            $this->sendJsonResponse(['success' => false, 'error' => 'Database insert failed: ' . $e->getMessage()], 500);
            return;
        }

        if (!$kNews) {
            $this->logApi("Blog create failed: no kNews ID");
            $this->sendJsonResponse(['success' => false, 'error' => 'Database insert failed: no ID returned'], 500);
            return;
        }

        // 2. INSERT INTO tnewssprache (Inhalte: Titel, Text, Meta)
        try {
            $db->queryPrepared(
                "INSERT INTO tnewssprache (kNews, languageID, languageCode, title, content, preview,
                 metaTitle, metaKeywords, metaDescription)
                 VALUES (:kNews, :langID, :langCode, :title, :content, :preview,
                 :metaTitle, :metaKeys, :metaDesc)",
                [
                    'kNews' => (int)$kNews,
                    'langID' => 1,
                    'langCode' => 'ger',
                    'title' => htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
                    'content' => $cleanHtml,
                    'preview' => $previewText,
                    'metaTitle' => $metaTitle,
                    'metaKeys' => $metaKeywords,
                    'metaDesc' => $metaDescription
                ],
                3
            );
        } catch (\Exception $e) {
            $this->logApi("Blog tnewssprache insert error: " . $e->getMessage());
            $this->sendJsonResponse(['success' => false, 'error' => 'Database insert (tnewssprache) failed: ' . $e->getMessage()], 500);
            return;
        }

        // 3. INSERT INTO tseo
        try {
            $db->queryPrepared(
                "INSERT INTO tseo (cSeo, cKey, kKey, kSprache) VALUES (:seo, 'kNews', :kKey, 1)",
                ['seo' => $seoSlug, 'kKey' => (int)$kNews],
                3
            );
        } catch (\Exception $e) {
            $this->logApi("Blog tseo insert error: " . $e->getMessage());
        }

        // 4. INSERT INTO tnewskategorienews
        try {
            $db->queryPrepared(
                "INSERT INTO tnewskategorienews (kNews, kNewsKategorie) VALUES (:kNews, :kKat)",
                ['kNews' => (int)$kNews, 'kKat' => $newsCategoryId],
                3
            );
        } catch (\Exception $e) {
            $this->logApi("Blog category insert error: " . $e->getMessage());
        }

        $this->logApi("Blog post created: kNews=$kNews, seo=$seoSlug, title=$title");

        $this->sendJsonResponse([
            'success' => true,
            'kNews' => (int)$kNews,
            'seo_url' => $seoSlug,
            'message' => 'Blog-Beitrag erfolgreich erstellt'
        ]);
    }

    private function handleBlogUpdateApiRequest(): void
    {
        // Nur POST erlauben
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
            return;
        }

        if ($this->isRateLimited()) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Too many requests'], 429);
            return;
        }

        $rawBody = file_get_contents('php://input');
        $data = json_decode($rawBody, true);

        if (!$data || !is_array($data)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Invalid JSON'], 400);
            return;
        }

        // Authentifizierung
        $authEmail = trim($data['auth_email'] ?? '');
        $authCode = trim($data['auth_code'] ?? '');

        if (empty($authEmail) || empty($authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing credentials'], 401);
            return;
        }

        if (!$this->authenticateApiRequest($authEmail, $authCode)) {
            $this->recordFailedAuth();
            $this->sendJsonResponse(['success' => false, 'error' => 'Authentication failed'], 401);
            return;
        }

        // kNews (Pflichtfeld fuer Update)
        $kNews = (int)($data['kNews'] ?? 0);
        if ($kNews <= 0) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing field: kNews'], 400);
            return;
        }

        $db = Shop::Container()->getDB();

        // Pruefen ob der Beitrag existiert
        $existingNews = $db->queryPrepared(
            "SELECT kNews FROM tnews WHERE kNews = :kNews",
            ['kNews' => $kNews],
            1
        );

        if (!$existingNews) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Blog post not found: kNews=' . $kNews], 404);
            return;
        }

        // Felder auslesen
        $title = trim($data['title'] ?? '');
        $htmlContent = $data['html_content'] ?? '';

        if (empty($title)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing field: title'], 400);
            return;
        }

        if (empty($htmlContent)) {
            $this->sendJsonResponse(['success' => false, 'error' => 'Missing field: html_content'], 400);
            return;
        }

        // HTML sanitizen
        $allowedTags = '<h1><h2><h3><h4><h5><p><br><ul><ol><li><strong><em><a><img><table><tr><td><th><thead><tbody><blockquote><figure><figcaption>';
        $cleanHtml = strip_tags($htmlContent, $allowedTags);
        $cleanHtml = preg_replace('/\s+on\w+\s*=\s*"[^"]*"/i', '', $cleanHtml);
        $cleanHtml = preg_replace('/\s+on\w+\s*=\s*\'[^\']*\'/i', '', $cleanHtml);
        $cleanHtml = preg_replace('/href\s*=\s*"javascript:[^"]*"/i', '', $cleanHtml);

        $previewText = htmlspecialchars(trim($data['preview_text'] ?? ''), ENT_QUOTES, 'UTF-8');
        $metaTitle = htmlspecialchars(trim($data['meta_title'] ?? $title), ENT_QUOTES, 'UTF-8');
        $metaDescription = htmlspecialchars(trim($data['meta_description'] ?? ''), ENT_QUOTES, 'UTF-8');
        $metaKeywords = htmlspecialchars(trim($data['meta_keywords'] ?? ''), ENT_QUOTES, 'UTF-8');
        $active = ($data['active'] ?? true) ? 1 : 0;

        // Vorschaubild verarbeiten (Base64 -> Datei)
        $previewImagePath = null; // null = nicht aendern
        $previewImageBase64 = trim($data['preview_image'] ?? '');
        if (!empty($previewImageBase64)) {
            try {
                $imageData = base64_decode($previewImageBase64, true);
                if ($imageData !== false && strlen($imageData) > 0) {
                    $finfo = new \finfo(FILEINFO_MIME_TYPE);
                    $mimeType = $finfo->buffer($imageData);
                    $ext = 'jpg';
                    if ($mimeType === 'image/png') $ext = 'png';
                    elseif ($mimeType === 'image/webp') $ext = 'webp';
                    elseif ($mimeType === 'image/gif') $ext = 'gif';

                    $seoSlug = trim($data['seo_slug'] ?? 'blog');
                    $fileName = 'wcs_blog_' . $this->sanitizeBlogSeoSlug($seoSlug) . '_' . time() . '.' . $ext;

                    $mediaDir = \PFAD_ROOT . 'media/image/news/';
                    if (!is_dir($mediaDir)) {
                        mkdir($mediaDir, 0755, true);
                    }

                    $filePath = $mediaDir . $fileName;
                    if (file_put_contents($filePath, $imageData) !== false) {
                        $previewImagePath = 'media/image/news/' . $fileName;
                        $this->logApi("Blog update preview image saved: " . $previewImagePath);

                        // Altes Bild loeschen
                        $oldImg = $db->queryPrepared(
                            "SELECT cPreviewImage FROM tnews WHERE kNews = :kNews",
                            ['kNews' => $kNews],
                            1
                        );
                        if ($oldImg && !empty($oldImg->cPreviewImage)) {
                            $oldPath = \PFAD_ROOT . $oldImg->cPreviewImage;
                            if (file_exists($oldPath) && strpos($oldImg->cPreviewImage, 'wcs_blog_') !== false) {
                                @unlink($oldPath);
                                $this->logApi("Blog old preview image deleted: " . $oldImg->cPreviewImage);
                            }
                        }
                    }
                }
            } catch (\Exception $imgEx) {
                $this->logApi("Blog update preview image error: " . $imgEx->getMessage());
            }
        } elseif (isset($data['preview_image']) && $data['preview_image'] === '') {
            // Explizit leerer String = Bild entfernen
            $previewImagePath = '';
            // Altes Bild loeschen
            $oldImg = $db->queryPrepared(
                "SELECT cPreviewImage FROM tnews WHERE kNews = :kNews",
                ['kNews' => $kNews],
                1
            );
            if ($oldImg && !empty($oldImg->cPreviewImage)) {
                $oldPath = \PFAD_ROOT . $oldImg->cPreviewImage;
                if (file_exists($oldPath) && strpos($oldImg->cPreviewImage, 'wcs_blog_') !== false) {
                    @unlink($oldPath);
                }
            }
        }

        // 1. UPDATE tnews
        try {
            $updateSql = "UPDATE tnews SET nAktiv = :aktiv";
            $params = ['aktiv' => $active, 'kNews' => $kNews];

            if ($previewImagePath !== null) {
                $updateSql .= ", cPreviewImage = :previewImage";
                $params['previewImage'] = $previewImagePath;
            }

            $updateSql .= " WHERE kNews = :kNews";

            $db->queryPrepared($updateSql, $params, 3);
        } catch (\Exception $e) {
            $this->logApi("Blog update tnews error: " . $e->getMessage());
            $this->sendJsonResponse(['success' => false, 'error' => 'Database update failed: ' . $e->getMessage()], 500);
            return;
        }

        // 2. UPDATE tnewssprache
        try {
            $db->queryPrepared(
                "UPDATE tnewssprache SET
                    title = :title,
                    content = :content,
                    preview = :preview,
                    metaTitle = :metaTitle,
                    metaKeywords = :metaKeys,
                    metaDescription = :metaDesc
                 WHERE kNews = :kNews AND languageID = 1",
                [
                    'kNews' => $kNews,
                    'title' => htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
                    'content' => $cleanHtml,
                    'preview' => $previewText,
                    'metaTitle' => $metaTitle,
                    'metaKeys' => $metaKeywords,
                    'metaDesc' => $metaDescription
                ],
                3
            );
        } catch (\Exception $e) {
            $this->logApi("Blog update tnewssprache error: " . $e->getMessage());
            $this->sendJsonResponse(['success' => false, 'error' => 'Database update (tnewssprache) failed: ' . $e->getMessage()], 500);
            return;
        }

        // 3. SEO-URL aktualisieren (optional, nur wenn gesendet)
        $seoSlug = trim($data['seo_slug'] ?? '');
        if (!empty($seoSlug)) {
            $seoSlug = $this->sanitizeBlogSeoSlug($seoSlug);
            try {
                // Bestehende SEO-URL pruefen
                $existingSeo = $db->queryPrepared(
                    "SELECT cSeo FROM tseo WHERE cKey = 'kNews' AND kKey = :kKey AND kSprache = 1",
                    ['kKey' => $kNews],
                    1
                );

                if ($existingSeo) {
                    // Nur updaten wenn sich der Slug geaendert hat
                    if ($existingSeo->cSeo !== $seoSlug) {
                        // Duplikat-Check
                        $dupCheck = $db->queryPrepared(
                            "SELECT cSeo FROM tseo WHERE cSeo = :seo AND NOT (cKey = 'kNews' AND kKey = :kKey)",
                            ['seo' => $seoSlug, 'kKey' => $kNews],
                            1
                        );
                        if (!$dupCheck) {
                            $db->queryPrepared(
                                "UPDATE tseo SET cSeo = :seo WHERE cKey = 'kNews' AND kKey = :kKey AND kSprache = 1",
                                ['seo' => $seoSlug, 'kKey' => $kNews],
                                3
                            );
                        }
                    }
                }
            } catch (\Exception $e) {
                $this->logApi("Blog update tseo error: " . $e->getMessage());
            }
        }

        // 4. Kategorie aktualisieren (optional)
        $newsCategoryId = isset($data['news_category_id']) ? (int)$data['news_category_id'] : 0;
        if ($newsCategoryId > 0) {
            try {
                $db->queryPrepared(
                    "DELETE FROM tnewskategorienews WHERE kNews = :kNews",
                    ['kNews' => $kNews],
                    3
                );
                $db->queryPrepared(
                    "INSERT INTO tnewskategorienews (kNews, kNewsKategorie) VALUES (:kNews, :kKat)",
                    ['kNews' => $kNews, 'kKat' => $newsCategoryId],
                    3
                );
            } catch (\Exception $e) {
                $this->logApi("Blog update category error: " . $e->getMessage());
            }
        }

        $this->logApi("Blog post updated: kNews=$kNews, title=$title");

        $this->sendJsonResponse([
            'success' => true,
            'kNews' => $kNews,
            'message' => 'Blog-Beitrag erfolgreich aktualisiert'
        ]);
    }

    private function sanitizeBlogSeoSlug(string $slug): string
    {
        $slug = mb_strtolower($slug, 'UTF-8');

        // Deutsche Umlaute
        $slug = str_replace(
            ['ä', 'ö', 'ü', 'ß', 'Ä', 'Ö', 'Ü'],
            ['ae', 'oe', 'ue', 'ss', 'ae', 'oe', 'ue'],
            $slug
        );

        // Nur alphanumerisch und Bindestriche
        $slug = preg_replace('/[^a-z0-9\-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');

        // Maximale Laenge
        if (mb_strlen($slug) > 200) {
            $slug = rtrim(mb_substr($slug, 0, 200), '-');
        }

        return $slug;
    }

    private function sendJsonResponse(array $data, int $httpCode = 200): void
    {
        http_response_code($httpCode);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    private function logApi(string $message): void
    {
        $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        @file_put_contents($logFile, "[$timestamp] [API] [$ip] $message\n", FILE_APPEND);
    }
}
