# WCS Structured Data für JTL-Shop 5

Optimiert Ihren JTL-Shop für Suchmaschinen und Social Media durch strukturierte Daten.

## Features

### Schema.org JSON-LD

- **Product Schema** - Vollständige Produktdaten für Google Rich Results
  - Name, Beschreibung, URL
  - SKU, GTIN/EAN (GTIN8, GTIN12, GTIN13, GTIN14), MPN
  - Marke/Hersteller
  - Produktbilder
  - Preis, Währung, Verfügbarkeit
  - Artikelzustand
  - Verkäufer (Organization)
  - Preisgültigkeit

- **BreadcrumbList Schema** - Navigationspfad für bessere Darstellung in Suchergebnissen
  - Automatische Duplikat-Erkennung
  - Korrekte Hierarchie (Startseite → Kategorien → Produkt)

- **AggregateRating** - Produktbewertungen für Sterneanzeige in Google
  - Durchschnittsbewertung
  - Anzahl Bewertungen

- **FAQ Schema** - FAQ-Bereich als strukturierte Daten für Google
  - Automatische Erkennung per Marker oder Überschriften
  - Duplikat-Handling konfigurierbar
  - Min. 2, max. 6 FAQ-Einträge

### OpenGraph Meta-Tags

- Optimierte Darstellung beim Teilen auf Facebook, LinkedIn, etc.
- og:type wird von "website" auf "product" korrigiert
- Vollständige Produktinformationen:
  - og:title, og:description, og:image, og:url
  - product:price:amount, product:price:currency
  - product:availability, product:brand

## Installation

1. ZIP-Datei über JTL-Shop Backend hochladen (Plugins → Pluginverwaltung → Upload)
2. Plugin installieren
3. Plugin aktivieren
4. Einstellungen nach Bedarf anpassen

## Einstellungen

| Einstellung | Beschreibung | Standard |
|-------------|--------------|----------|
| Plugin aktivieren | Gesamtes Plugin an/aus | An |
| JSON-LD Product Schema | Product-Daten ausgeben | An |
| JSON-LD Breadcrumb Schema | Navigationspfad ausgeben | An |
| Bewertungen (aggregateRating) | Bewertungen ausgeben wenn vorhanden | An |
| FAQ Schema aktivieren | FAQ aus Produktbeschreibung ausgeben | An |
| FAQ Duplikat-Handling | Bei doppelten Fragen: erste behalten (skip) oder letzte behalten (override) | skip |
| OpenGraph Meta-Tags | OG-Tags optimieren | An |
| OpenGraph Tags ersetzen | Bestehende Tags ersetzen statt hinzufügen | An |
| Debug-Modus | Logging in /jtllogs/wcs_structured_data.log | Aus |

## FAQ Schema - Dokumentation

Das Plugin erkennt FAQ-Bereiche in der Produktbeschreibung automatisch.

### Methode 1: WCS-Marker (empfohlen)

Umschließen Sie den FAQ-Bereich mit Markern:

```html
<!--WCS_FAQ_START-->
<h2>Fragen und Antworten</h2>
<h3>Wie lang ist die Lieferzeit?</h3>
<p>Die Lieferzeit beträgt 2-3 Werktage.</p>
<h3>Gibt es Garantie?</h3>
<p>Ja, 2 Jahre gesetzliche Gewährleistung.</p>
<!--WCS_FAQ_END-->
```

### Methode 2: H2-Überschriften (Fallback)

Ohne Marker sucht das Plugin nach H2-Überschriften mit folgenden Texten:
- FAQ
- Fragen und Antworten
- Fragen
- Häufige Fragen

### Aufbau

- **H3** = Frage
- **Inhalt nach H3** (bis zum nächsten H3) = Antwort
- Minimum: 2 FAQ-Einträge
- Maximum: 6 FAQ-Einträge

### Duplikat-Handling

Falls dieselbe Frage mehrfach vorkommt:
- **skip** (Standard): Erste Frage wird behalten
- **override**: Letzte Frage überschreibt vorherige

## Systemvoraussetzungen

- JTL-Shop 5.0.0 oder höher
- PHP 7.4 oder höher

## Validierung

Prüfen Sie die strukturierten Daten mit:
- [Google Rich Results Test](https://search.google.com/test/rich-results)
- [Schema.org Validator](https://validator.schema.org/)
- [Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/)

## Debug-Modus

Bei aktiviertem Debug-Modus werden Informationen in folgende Datei geschrieben:
```
/jtllogs/wcs_structured_data.log
```

Enthält:
- Verarbeitete Produkte
- Gefundene FAQ-Einträge
- Fehler bei der Schema-Generierung

## Support

Bei Fragen oder Problemen:
- Website: https://wavi-suite.de
- E-Mail: support@wavi-suite.de

## Lizenz

Proprietär - Lizenzschlüssel erforderlich

## Changelog

### Version 1.2.8 (2025-01-03)
- Entfernt: FAQ bei Varianten Einstellung (nicht praktikabel)
- Aufgeräumt: Debug-Code für Varianten entfernt

### Version 1.2.6 (2025-01-03)
- Neu: FAQ Schema (FAQPage)
- Neu: FAQ Duplikat-Handling Einstellung
- Neu: Automatische FAQ-Erkennung per WCS-Marker
- Neu: Fallback FAQ-Erkennung per H2-Whitelist

### Version 1.1.5 (2025-01-02)
- Bugfix: 500-Fehler bei Artikeln ohne FAQ behoben
- Verbessert: Defensive Programmierung mit try-catch

### Version 1.1.3 (2025-01-01)
- Initiale Store-Version
- Product Schema (JSON-LD)
- BreadcrumbList Schema (JSON-LD)
- OpenGraph Tag-Optimierung
- Bewertungen (aggregateRating)
- Konfigurierbare Einstellungen
- Debug-Modus

---

Entwickelt von [WAVI Creator Suite](https://wavi-suite.de)
