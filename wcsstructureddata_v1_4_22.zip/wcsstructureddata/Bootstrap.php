<?php

/**
 * WCS Structured Data Plugin for JTL-Shop 5
 * 
 * @author WAVI Creator Suite
 * @copyright 2025 WAVI Creator Suite
 * @license MIT
 * @version 1.4.22
 */

declare(strict_types=1);

namespace Plugin\wcsstructureddata;

use JTL\Events\Dispatcher;
use JTL\Plugin\Bootstrapper;
use JTL\Shop;

class Bootstrap extends Bootstrapper
{
    private array $config = [];

    public function boot(Dispatcher $dispatcher): void
    {
        parent::boot($dispatcher);
        
        if (!Shop::isFrontend()) {
            return;
        }

        $this->loadConfig();
        
        if ($this->config['wcs_active'] !== 'on') {
            return;
        }

        $dispatcher->listen('shop.hook.' . \HOOK_SMARTY_OUTPUTFILTER, function(array &$args) {
            $this->onOutputFilter($args);
        });

        // Hook für Merkmal-Transformation (Unterstrich-Encoding entfernen)
        if ($this->config['wcs_merkmal_transform'] === 'on') {
            $dispatcher->listen('shop.hook.' . \HOOK_ARTIKEL_CLASS_FUELLEARTIKEL, function(array &$args) {
                $this->transformWcsMerkmale($args);
            }, 1);
            
            // Output Buffer starten um Unterstrich-Encoding aus HTML zu entfernen
            if (!defined('WCS_OUTPUT_BUFFER_STARTED')) {
                define('WCS_OUTPUT_BUFFER_STARTED', true);
                ob_start(function($html) {
                    return $this->removeWcsPrefixFromOutput($html);
                });
            }
        }
    }

    public function installed(): void
    {
        parent::installed();
    }

    public function uninstalled(bool $deleteData = true): void
    {
        parent::uninstalled($deleteData);
        
        $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
        if (file_exists($logFile) && $deleteData) {
            @unlink($logFile);
        }
    }

    public function updated($oldVersion, $newVersion): void
    {
        parent::updated($oldVersion, $newVersion);
    }

    private function loadConfig(): void
    {
        $plugin = $this->getPlugin();
        $config = $plugin->getConfig();
        
        $this->config = [
            'wcs_active' => $config->getValue('wcs_active') ?? 'on',
            'wcs_merkmal_transform' => $config->getValue('wcs_merkmal_transform') ?? 'on',
            'wcs_product_schema' => $config->getValue('wcs_product_schema') ?? 'on',
            'wcs_breadcrumb_schema' => $config->getValue('wcs_breadcrumb_schema') ?? 'on',
            'wcs_aggregate_rating' => $config->getValue('wcs_aggregate_rating') ?? 'on',
            'wcs_faq_schema' => $config->getValue('wcs_faq_schema') ?? 'on',
            'wcs_faq_duplicate' => $config->getValue('wcs_faq_duplicate') ?? 'skip',
            'wcs_opengraph' => $config->getValue('wcs_opengraph') ?? 'on',
            'wcs_og_replace' => $config->getValue('wcs_og_replace') ?? 'on',
            'wcs_internal_linking' => $config->getValue('wcs_internal_linking') ?? 'on',
            'wcs_debug' => $config->getValue('wcs_debug') ?? '',
        ];
    }

    private function log(string $message): void
    {
        if ($this->config['wcs_debug'] !== 'on' && !empty($this->config)) {
            return;
        }
        
        $logFile = \PFAD_ROOT . 'jtllogs/wcs_structured_data.log';
        $timestamp = date('Y-m-d H:i:s');
        @file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
    }

    private function checkLicense(): bool
    {
        // Lizenzdatei (vom Admin-Controller gespeichert)
        $licenseFile = \PFAD_ROOT . 'jtllogs/wcs_license.json';
        
        if (!file_exists($licenseFile)) {
            $this->log('License check: No license file found');
            return false;
        }
        
        $licenseData = json_decode(file_get_contents($licenseFile), true);
        
        if (!$licenseData) {
            $this->log('License check: Invalid license file');
            return false;
        }
        
        $isValid = $licenseData['license_valid'] ?? false;
        $validUntil = $licenseData['valid_until'] ?? 0;
        
        // Wenn Cache abgelaufen, Lizenz erneut prüfen
        if ($validUntil < time()) {
            $email = $licenseData['email'] ?? '';
            $code = $licenseData['code'] ?? '';
            
            if (empty($email) || empty($code)) {
                $this->log('License check: No credentials in license file');
                return false;
            }
            
            // Lizenzserver abfragen
            $isValid = $this->verifyLicenseOnServer($email, $code);
            
            // Lizenzdatei aktualisieren
            $licenseData['license_valid'] = $isValid;
            $licenseData['valid_until'] = time() + 86400; // 24 Stunden
            $licenseData['checked_at'] = date('Y-m-d H:i:s');
            @file_put_contents($licenseFile, json_encode($licenseData, JSON_PRETTY_PRINT));
        }
        
        $this->log('License check: ' . ($isValid ? 'VALID' : 'INVALID'));
        return $isValid;
    }
    
    private function verifyLicenseOnServer(string $email, string $code): bool
    {
        $licenseServerUrl = 'https://www.wawicreatorsuite.de/api/license.php';
        $domain = $_SERVER['HTTP_HOST'] ?? '';
        
        $postData = [
            'email' => $email,
            'license_code' => $code,
            'product' => 'wcs_structured_data',
            'domain' => $domain
        ];
        
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $licenseServerUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 && $response) {
                $result = json_decode($response, true);
                return $result['license_valid'] ?? false;
            }
            
            $this->log('License verify: Server error - HTTP ' . $httpCode);
            
        } catch (\Throwable $e) {
            $this->log('License verify: Exception - ' . $e->getMessage());
        }
        
        return false;
    }

    public function onOutputFilter(array &$args): void
    {
        // Alles in try-catch für maximale Sicherheit
        try {
            $smarty = $args['smarty'] ?? null;
            $document = $args['document'] ?? null;
            
            if ($smarty === null || $document === null) {
                $this->log('ERROR: smarty or document is NULL');
                return;
            }

            // Lizenzprüfung
            if (!$this->checkLicense()) {
                $this->log('License check failed - stopping');
                return;
            }

            // PageType sicher ermitteln
            $pageType = null;
            try {
                $pageType = Shop::getPageType();
            } catch (\Throwable $e) {
                $this->log('getPageType error: ' . $e->getMessage());
            }

            $this->log('PageType: ' . $pageType);
            
            // DEBUG: Prüfe IMMER ob ein Artikel vorhanden ist
            $product = $smarty->getTemplateVars('Artikel');
            $this->log('Artikel variable exists: ' . ($product !== null ? 'YES' : 'NO'));
            
            if ($product !== null) {
                $this->log('Product found! Name: ' . ($product->cName ?? 'unknown') . ', kArtikel: ' . ($product->kArtikel ?? 'unknown'));
            }
            
            // DEBUG: Zeige alle verfügbaren Smarty-Variablen
            $allVars = $smarty->getTemplateVars();
            $varNames = is_array($allVars) ? array_keys($allVars) : [];
            $this->log('Available Smarty vars: ' . implode(', ', array_slice($varNames, 0, 30)));

            // Page-Typen in JTL-Shop 5:
            // 2 = Kategorie, 3 = Artikel
            $PAGE_KATEGORIE = 2;
            $PAGE_ARTIKEL = 3;

            // Interne Verlinkung auf Kategorieseiten
            if ($pageType === $PAGE_KATEGORIE) {
                $this->log('Category page - checking internal linking setting');
                $linkingSetting = $this->config['wcs_internal_linking'] ?? 'on';
                $this->log('wcs_internal_linking = ' . $linkingSetting);
                
                if ($linkingSetting === 'on') {
                    $this->log('Calling processCategoryInternalLinks');
                    $this->processCategoryInternalLinks($args);
                }
                return;
            }

            // GEÄNDERT: Wenn Produkt vorhanden, verarbeiten - unabhängig vom PageType
            if ($product !== null && !empty($product->kArtikel)) {
                $this->log('Processing product (PageType=' . $pageType . '): ' . ($product->cName ?? 'unknown'));
                
                $shopUrl = rtrim(Shop::getURL(), '/');
                $shopName = Shop::getSettingValue(\CONF_GLOBAL, 'global_shopname') ?: 'Shop';
                
                $html = '<!-- WCS Structured Data START -->';
                
                // 1. Product Schema
                $this->log('wcs_product_schema setting: ' . ($this->config['wcs_product_schema'] ?? 'not set'));
                if ($this->config['wcs_product_schema'] === 'on') {
                    $this->log('Building Product Schema...');
                    $productSchema = $this->buildProductSchema($product, $shopUrl);
                    $html .= '<script type="application/ld+json">' . json_encode($productSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
                    $this->log('Product Schema added');
                }
                
                // 2. Breadcrumb Schema
                if ($this->config['wcs_breadcrumb_schema'] === 'on') {
                    $this->log('Building Breadcrumb Schema...');
                    $breadcrumbSchema = $this->buildBreadcrumbSchema($product, $smarty, $shopUrl);
                    if ($breadcrumbSchema !== null) {
                        $html .= '<script type="application/ld+json">' . json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
                        $this->log('Breadcrumb Schema added');
                    }
                }
                
                // 3. FAQ Schema
                if ($this->config['wcs_faq_schema'] === 'on') {
                    try {
                        $faqSchema = $this->buildFaqSchema($product);
                        if ($faqSchema !== null) {
                            $html .= '<script type="application/ld+json">' . json_encode($faqSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
                            $this->log('FAQ Schema generated with ' . count($faqSchema['mainEntity']) . ' items');
                        }
                    } catch (\Throwable $e) {
                        $this->log('FAQ Schema ERROR: ' . $e->getMessage());
                    }
                }
                
                $html .= '<!-- WCS Structured Data END -->';
                
                $this->log('Appending structured data to head...');
                $document->find('head')->append($html);
                $this->log('Structured data appended successfully');
                
                // 4. OpenGraph Tags
                if ($this->config['wcs_opengraph'] === 'on') {
                    $this->handleOpenGraphTags($document, $product, $shopUrl, $shopName);
                    $this->log('OpenGraph tags processed');
                }
                
                return;
            }
            
            $this->log('No product found for PageType ' . $pageType);
            
        } catch (\Throwable $e) {
            $this->log('onOutputFilter FATAL: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        }
    }

    // =====================================================
    // INTERNE VERLINKUNG - Neue Methoden für v1.4.0
    // =====================================================

    /**
     * Verarbeitet interne Link-Marker auf Kategorieseiten
     * Verwendet phpQuery API - sucht gezielt Elemente mit Markern
     */
    private function processCategoryInternalLinks(array &$args): void
    {
        try {
            if (!isset($args['document'])) {
                $this->log('No document in args');
                return;
            }
            
            $doc = $args['document'];
            
            // Hole das komplette HTML zur Prüfung
            $html = (string)$doc;
            
            if (empty($html) || strpos($html, '[link:') === false) {
                $this->log('No [link: markers found in page');
                return;
            }
            
            $this->log('Found [link: markers in page, searching for elements...');
            
            $success = false;
            
            // Mögliche Selektoren für Kategorie-Beschreibungen
            $selectors = [
                '.desc',
                '.category-description',
                '.description',
                '.category-desc',
                '#category-description',
                '.content-wrapper .desc',
                '.category-content',
                '.page-content',
                'main .desc',
                'article'
            ];
            
            foreach ($selectors as $selector) {
                try {
                    $elements = $doc->find($selector);
                    
                    if (!$elements || $elements->length === 0) {
                        continue;
                    }
                    
                    $this->log("Checking selector: $selector (found " . $elements->length . " elements)");
                    
                    // phpQuery each() mit Callback
                    foreach ($elements as $domElement) {
                        // Wrap in phpQuery für html() Zugriff
                        $pq = \JTL\phpQuery\phpQuery::pq($domElement);
                        $innerHtml = $pq->html();
                        
                        if (empty($innerHtml) || strpos($innerHtml, '[link:') === false) {
                            continue;
                        }
                        
                        $this->log("Found markers in $selector");
                        
                        // Marker ersetzen
                        $modifiedHtml = $this->replaceInternalLinkMarkers($innerHtml);
                        
                        if ($modifiedHtml !== $innerHtml) {
                            $pq->html($modifiedHtml);
                            $success = true;
                            $this->log("Replaced content in $selector");
                        }
                    }
                    
                    if ($success) {
                        break;
                    }
                    
                } catch (\Throwable $e) {
                    $this->log("Selector $selector error: " . $e->getMessage());
                    continue;
                }
            }
            
            // Fallback: Alle Elemente durchsuchen die [link: enthalten
            if (!$success) {
                $this->log('Trying wildcard search...');
                try {
                    // Suche nach allen ul/ol/p/div die möglicherweise die Marker enthalten
                    $containers = $doc->find('ul, ol, p, div');
                    
                    foreach ($containers as $domElement) {
                        $pq = \JTL\phpQuery\phpQuery::pq($domElement);
                        $innerHtml = $pq->html();
                        
                        if (!empty($innerHtml) && strpos($innerHtml, '[link:') !== false) {
                            $this->log('Found markers in ' . $domElement->nodeName);
                            
                            $modifiedHtml = $this->replaceInternalLinkMarkers($innerHtml);
                            
                            if ($modifiedHtml !== $innerHtml) {
                                $pq->html($modifiedHtml);
                                $success = true;
                                $this->log('Replaced content in ' . $domElement->nodeName);
                                break; // Nur das erste Element mit Markern
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    $this->log('Wildcard search error: ' . $e->getMessage());
                }
            }
            
            if ($success) {
                $this->log('Category internal links processed successfully');
            } else {
                $this->log('Markers found but could not locate containing element');
            }
            
        } catch (\Throwable $e) {
            $this->log('processCategoryInternalLinks error: ' . $e->getMessage());
        }
    }

    /**
     * Alte Methoden - nicht mehr verwendet
     */
    private function processInternalLinksOnPage($document): void
    {
        return;
    }

    private function processInternalLinks($document): void
    {
        return;
    }

    /**
     * Ersetzt Link-Marker durch echte HTML-Links
     * Marker-Format: [link:art:ID|LINKTEXT] oder [link:cat:ID|LINKTEXT]
     */
    private function replaceInternalLinkMarkers(string $html): string
    {
        if (empty($html)) {
            return $html;
        }
        
        // Artikel-Links: [link:art:123|Linktext]
        $html = preg_replace_callback(
            '/\[link:art:(\d+)\|([^\]]+)\]/',
            function($matches) {
                return $this->buildArticleLink((int)$matches[1], $matches[2]);
            },
            $html
        );
        
        // Kategorie-Links: [link:cat:123|Linktext]
        $html = preg_replace_callback(
            '/\[link:cat:(\d+)\|([^\]]+)\]/',
            function($matches) {
                return $this->buildCategoryLink((int)$matches[1], $matches[2]);
            },
            $html
        );
        
        return $html;
    }

    /**
     * Erstellt einen HTML-Link zu einem Artikel
     */
    private function buildArticleLink(int $articleId, string $linkText): string
    {
        try {
            // Artikel laden mit minimalen Optionen
            $article = new \JTL\Catalog\Product\Artikel();
            
            // Versuche verschiedene Methoden zum Laden
            $options = null;
            if (method_exists($article, 'getDefaultOptions')) {
                $options = \JTL\Catalog\Product\Artikel::getDefaultOptions();
            }
            
            if ($options !== null) {
                $article->fuelleArtikel($articleId, $options);
            } else {
                $article->fuelleArtikel($articleId);
            }
            
            if (empty($article->kArtikel) || $article->kArtikel <= 0) {
                $this->log("Article not found: $articleId");
                return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            }
            
            if (isset($article->cAktiv) && $article->cAktiv !== 'Y') {
                $this->log("Article not active: $articleId");
                return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            }
            
            $url = $article->cURLFull ?? $article->cURL ?? '';
            
            if (empty($url)) {
                $this->log("Article URL not found: $articleId");
                return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            }
            
            $shopUrl = rtrim(Shop::getURL(), '/');
            if (strpos($url, 'http') !== 0) {
                $url = $shopUrl . '/' . ltrim($url, '/');
            }
            
            $cleanLinkText = htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            $cleanUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
            
            $this->log("Created article link: $articleId -> $url");
            
            return '<a href="' . $cleanUrl . '">' . $cleanLinkText . '</a>';
            
        } catch (\Throwable $e) {
            $this->log("Article link error for $articleId: " . $e->getMessage());
            return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
        }
    }

    /**
     * Erstellt einen HTML-Link zu einer Kategorie
     */
    private function buildCategoryLink(int $categoryId, string $linkText): string
    {
        try {
            $category = new \JTL\Catalog\Category\Kategorie($categoryId);
            
            if (empty($category->kKategorie) || $category->kKategorie <= 0) {
                $this->log("Category not found: $categoryId");
                return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            }
            
            $url = $category->cURLFull ?? $category->cURL ?? '';
            
            if (empty($url)) {
                $this->log("Category URL not found: $categoryId");
                return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            }
            
            $shopUrl = rtrim(Shop::getURL(), '/');
            if (strpos($url, 'http') !== 0) {
                $url = $shopUrl . '/' . ltrim($url, '/');
            }
            
            $cleanLinkText = htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
            $cleanUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
            
            $this->log("Created category link: $categoryId -> $url");
            
            return '<a href="' . $cleanUrl . '">' . $cleanLinkText . '</a>';
            
        } catch (\Throwable $e) {
            $this->log("Category link error for $categoryId: " . $e->getMessage());
            return htmlspecialchars($linkText, ENT_QUOTES, 'UTF-8');
        }
    }

    // =====================================================
    // BESTEHENDE METHODEN (Product Schema, FAQ, etc.)
    // =====================================================

    private function buildProductSchema($product, string $shopUrl): array
    {
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => $this->cleanText($product->cName ?? 'Unbekannt'),
        ];
        
        if (!empty($product->cURLFull)) {
            $schema['url'] = $product->cURLFull;
        }
        
        if (!empty($product->cKurzBeschreibung)) {
            $schema['description'] = $this->cleanText($product->cKurzBeschreibung, 5000, true);
        } elseif (!empty($product->cBeschreibung)) {
            $schema['description'] = $this->cleanText($product->cBeschreibung, 5000, true);
        }
        
        if (!empty($product->cArtNr)) {
            $schema['sku'] = $product->cArtNr;
        }
        
        if (!empty($product->cBarcode)) {
            $gtin = preg_replace('/[^0-9]/', '', $product->cBarcode);
            $schema['gtin'] = $gtin;
            
            $len = strlen($gtin);
            if ($len === 13) {
                $schema['gtin13'] = $gtin;
            } elseif ($len === 12) {
                $schema['gtin12'] = $gtin;
            } elseif ($len === 8) {
                $schema['gtin8'] = $gtin;
            } elseif ($len === 14) {
                $schema['gtin14'] = $gtin;
            }
        }
        
        if (!empty($product->cHAN)) {
            $schema['mpn'] = $product->cHAN;
        }
        
        if (!empty($product->cHersteller)) {
            $schema['brand'] = [
                '@type' => 'Brand',
                'name' => $product->cHersteller,
            ];
        }
        
        $images = $this->getProductImages($product, $shopUrl);
        if (!empty($images)) {
            $schema['image'] = $images;
        }
        
        if (isset($product->Preise->fVKBrutto) && $product->Preise->fVKBrutto > 0) {
            $schema['offers'] = $this->buildOffers($product, $shopUrl);
        }
        
        if ($this->config['wcs_aggregate_rating'] === 'on') {
            $rating = $this->getAggregateRating($product);
            if ($rating !== null) {
                $schema['aggregateRating'] = $rating;
            }
        }
        
        $schema['itemCondition'] = 'https://schema.org/NewCondition';
        
        return $schema;
    }

    private function getProductImages($product, string $shopUrl): array
    {
        $images = [];
        
        if (!empty($product->Bilder) && is_array($product->Bilder)) {
            foreach ($product->Bilder as $bild) {
                $imgUrl = $bild->cURLGross ?? $bild->cURLNormal ?? null;
                if (!empty($imgUrl)) {
                    $images[] = $this->makeAbsoluteUrl($imgUrl, $shopUrl);
                }
            }
        }
        
        return $images;
    }

    private function buildOffers($product, string $shopUrl): array
    {
        $price = number_format((float)$product->Preise->fVKBrutto, 2, '.', '');
        $currency = $_SESSION['Waehrung']->cISO ?? 'EUR';
        
        $availability = 'https://schema.org/InStock';
        if (isset($product->fLagerbestand) && (float)$product->fLagerbestand <= 0) {
            if (($product->cLagerBeachten ?? '') === 'Y') {
                $availability = 'https://schema.org/OutOfStock';
            }
        }

        $offers = [
            '@type' => 'Offer',
            'price' => $price,
            'priceCurrency' => $currency,
            'availability' => $availability,
            'url' => $product->cURLFull ?? $shopUrl,
            'itemCondition' => 'https://schema.org/NewCondition',
        ];
        
        $shopName = Shop::getSettingValue(\CONF_GLOBAL, 'global_shopname') ?: 'Shop';
        $offers['seller'] = [
            '@type' => 'Organization',
            'name' => $shopName,
        ];
        
        $offers['priceValidUntil'] = date('Y-m-d', strtotime('+30 days'));
        
        return $offers;
    }

    private function getAggregateRating($product): ?array
    {
        if (isset($product->Bewertungen) && 
            !empty($product->Bewertungen->nAnzahlSprache) && 
            $product->Bewertungen->nAnzahlSprache > 0) {
            
            return [
                '@type' => 'AggregateRating',
                'ratingValue' => number_format(
                    (float)($product->Bewertungen->fDurchschnitt ?? $product->fDurchschnittsBewertung ?? 0), 
                    1, '.', ''
                ),
                'reviewCount' => (int)$product->Bewertungen->nAnzahlSprache,
                'bestRating' => '5',
                'worstRating' => '1',
            ];
        }
        
        if (isset($product->fDurchschnittsBewertung) && 
            $product->fDurchschnittsBewertung > 0 && 
            isset($product->nAnzahlBewertungen) && 
            $product->nAnzahlBewertungen > 0) {
            
            return [
                '@type' => 'AggregateRating',
                'ratingValue' => number_format((float)$product->fDurchschnittsBewertung, 1, '.', ''),
                'reviewCount' => (int)$product->nAnzahlBewertungen,
                'bestRating' => '5',
                'worstRating' => '1',
            ];
        }
        
        return null;
    }

    private function buildFaqSchema($product): ?array
    {
        $description = $product->cBeschreibung ?? '';
        
        if (empty($description)) {
            $this->log('FAQ: No description found');
            return null;
        }
        
        $faqContent = '';
        
        // Methode 1: Marker suchen
        if (preg_match('/<!--WCS_FAQ_START-->(.*?)<!--WCS_FAQ_END-->/s', $description, $matches)) {
            $faqContent = $matches[1];
            $this->log('FAQ: Found WCS markers');
        } else {
            // Methode 2: H2 Whitelist
            $whitelist = [
                'FAQ',
                'Fragen und Antworten',
                'Fragen',
                'Häufige Fragen',
            ];
            
            foreach ($whitelist as $heading) {
                $pattern = '/<h2[^>]*>\s*' . preg_quote($heading, '/') . '\s*<\/h2>/i';
                if (preg_match($pattern, $description, $match, PREG_OFFSET_MATCH)) {
                    $startPos = $match[0][1];
                    $afterH2 = substr($description, $startPos);
                    
                    if (preg_match('/<h2[^>]*>/i', $afterH2, $nextH2Match, PREG_OFFSET_MATCH, strlen($match[0][0]))) {
                        $faqContent = substr($afterH2, 0, $nextH2Match[0][1]);
                    } else {
                        $faqContent = $afterH2;
                    }
                    
                    $this->log('FAQ: Found H2 whitelist heading: ' . $heading);
                    break;
                }
            }
        }
        
        if (empty($faqContent)) {
            $this->log('FAQ: No FAQ content found');
            return null;
        }
        
        $duplicateMode = $this->config['wcs_faq_duplicate'] ?? 'skip';
        $faqItems = $this->extractFaqItems($faqContent, $duplicateMode);
        
        if (count($faqItems) < 2) {
            $this->log('FAQ: Less than 2 items found (' . count($faqItems) . ')');
            return null;
        }
        
        if (count($faqItems) > 6) {
            $faqItems = array_slice($faqItems, 0, 6);
            $this->log('FAQ: Limited to 6 items');
        }
        
        $mainEntity = [];
        foreach ($faqItems as $item) {
            $mainEntity[] = [
                '@type' => 'Question',
                'name' => $item['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $item['answer'],
                ],
            ];
        }
        
        return [
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'mainEntity' => $mainEntity,
        ];
    }

    private function extractFaqItems(string $content, string $duplicateMode = 'skip'): array
    {
        $items = [];
        $usedQuestions = [];
        
        if (empty($content)) {
            return $items;
        }
        
        $pattern = '/<h3[^>]*>(.*?)<\/h3>(.*?)(?=<h3[^>]*>|$)/si';
        
        if (preg_match_all($pattern, $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                if (!isset($match[1]) || !isset($match[2])) {
                    continue;
                }
                
                $questionRaw = strip_tags($match[1]);
                $answerRaw = strip_tags($match[2]);
                
                if (!is_string($questionRaw) || !is_string($answerRaw)) {
                    continue;
                }
                
                $question = $this->cleanText($questionRaw);
                $answer = $this->cleanText($answerRaw, 0, true);
                
                if (empty($question) || empty($answer)) {
                    continue;
                }
                
                $questionLower = mb_strtolower($question);
                if (isset($usedQuestions[$questionLower])) {
                    if ($duplicateMode === 'override') {
                        $existingIndex = $usedQuestions[$questionLower];
                        $items[$existingIndex] = [
                            'question' => $question,
                            'answer' => $answer,
                        ];
                        $this->log('FAQ: Overriding duplicate question: ' . $question);
                    } else {
                        $this->log('FAQ: Skipping duplicate question: ' . $question);
                    }
                    continue;
                }
                
                $usedQuestions[$questionLower] = count($items);
                $items[] = [
                    'question' => $question,
                    'answer' => $answer,
                ];
            }
        }
        
        return $items;
    }

    private function buildBreadcrumbSchema($product, $smarty, string $shopUrl): ?array
    {
        $items = [];
        $usedUrls = [];
        $usedNames = [];
        $pos = 1;
        
        $shopUrl = rtrim($shopUrl, '/');
        
        $items[] = [
            '@type' => 'ListItem',
            'position' => $pos++,
            'name' => 'Startseite',
            'item' => $shopUrl,
        ];
        $usedUrls[$this->normalizeUrl($shopUrl)] = true;
        $usedNames['startseite'] = true;
        
        $categories = $this->extractCategories($product, $smarty, $shopUrl);
        
        $this->log('Extracted categories count: ' . count($categories));
        
        $productUrl = $this->normalizeUrl($product->cURLFull ?? '');
        $productNameLower = mb_strtolower($this->cleanText($product->cName ?? ''));
        
        foreach ($categories as $cat) {
            $catUrlNormalized = $this->normalizeUrl($cat['url']);
            $catNameLower = mb_strtolower($cat['name']);
            
            if (isset($usedUrls[$catUrlNormalized])) {
                $this->log('Skipping duplicate URL: ' . $cat['url']);
                continue;
            }
            
            if (isset($usedNames[$catNameLower])) {
                $this->log('Skipping duplicate name: ' . $cat['name']);
                continue;
            }
            
            if ($catUrlNormalized === $productUrl) {
                $this->log('Skipping product URL: ' . $cat['url']);
                continue;
            }
            
            if ($catNameLower === $productNameLower) {
                $this->log('Skipping product name: ' . $cat['name']);
                continue;
            }
            
            $items[] = [
                '@type' => 'ListItem',
                'position' => $pos++,
                'name' => $cat['name'],
                'item' => rtrim($cat['url'], '/'),
            ];
            $usedUrls[$catUrlNormalized] = true;
            $usedNames[$catNameLower] = true;
        }
        
        $productName = $this->cleanText($product->cName ?? '');
        
        if (!empty($productName) && !empty($productUrl)) {
            if (!isset($usedUrls[$productUrl]) && !isset($usedNames[$productNameLower])) {
                $items[] = [
                    '@type' => 'ListItem',
                    'position' => $pos,
                    'name' => $productName,
                    'item' => rtrim($product->cURLFull, '/'),
                ];
            }
        }
        
        if (count($items) < 2) {
            return null;
        }
        
        return [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $items,
        ];
    }

    private function normalizeUrl(string $url): string
    {
        $url = mb_strtolower(trim($url));
        $url = rtrim($url, '/');
        return $url;
    }

    private function extractCategories($product, $smarty, string $shopUrl): array
    {
        $categories = [];
        
        $breadcrumbs = $smarty->getTemplateVars('Brotnavi');
        if ($breadcrumbs !== null && is_iterable($breadcrumbs)) {
            foreach ($breadcrumbs as $crumb) {
                $name = null;
                $url = null;
                
                if (is_object($crumb)) {
                    $name = $crumb->cName ?? $crumb->name ?? $crumb->title ?? $crumb->cBeschreibung ?? null;
                    $url = $crumb->cURLFull ?? $crumb->cURL ?? $crumb->url ?? $crumb->cSeo ?? null;
                    
                    if (empty($url) && !empty($crumb->cSeo)) {
                        $url = $shopUrl . '/' . ltrim($crumb->cSeo, '/');
                    }
                } elseif (is_array($crumb)) {
                    $name = $crumb['cName'] ?? $crumb['name'] ?? null;
                    $url = $crumb['cURLFull'] ?? $crumb['cURL'] ?? null;
                }
                
                if (!empty($name) && !empty($url)) {
                    $categories[] = [
                        'name' => $this->cleanText($name),
                        'url' => $this->makeAbsoluteUrl($url, $shopUrl),
                    ];
                }
            }
        }
        
        if (empty($categories) && isset($product->oKategorie_arr) && is_array($product->oKategorie_arr)) {
            foreach ($product->oKategorie_arr as $kat) {
                if (is_object($kat)) {
                    $name = $kat->cName ?? null;
                    $url = $kat->cURLFull ?? $kat->cURL ?? null;
                    
                    if (!empty($name) && !empty($url)) {
                        $categories[] = [
                            'name' => $this->cleanText($name),
                            'url' => $this->makeAbsoluteUrl($url, $shopUrl),
                        ];
                    }
                }
            }
        }
        
        if (empty($categories) && isset($product->Kategorie) && is_object($product->Kategorie)) {
            $kat = $product->Kategorie;
            $name = $kat->cName ?? null;
            $url = $kat->cURLFull ?? $kat->cURL ?? null;
            
            if (!empty($name) && !empty($url)) {
                $categories[] = [
                    'name' => $this->cleanText($name),
                    'url' => $this->makeAbsoluteUrl($url, $shopUrl),
                ];
            }
        }
        
        return $categories;
    }

    private function handleOpenGraphTags($document, $product, string $shopUrl, string $shopName): void
    {
        $productName = $this->cleanText($product->cName ?? '');
        
        $description = '';
        if (!empty($product->cKurzBeschreibung)) {
            $description = $this->cleanText($product->cKurzBeschreibung, 300, true);
        } elseif (!empty($product->cBeschreibung)) {
            $description = $this->cleanText($product->cBeschreibung, 300, true);
        }
        
        $images = $this->getProductImages($product, $shopUrl);
        $imageUrl = !empty($images) ? $images[0] : '';
        
        $document->find('meta[property="og:type"]')->remove();
        $document->find('head')->append('<meta property="og:type" content="product">');
        
        $document->find('meta[property="og:site_name"]')->remove();
        $document->find('head')->append('<meta property="og:site_name" content="' . htmlspecialchars($shopName, ENT_QUOTES, 'UTF-8') . '">');
        
        if (!empty($productName)) {
            $document->find('meta[property="og:title"]')->remove();
            $document->find('head')->append('<meta property="og:title" content="' . htmlspecialchars($productName, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (!empty($description)) {
            $document->find('meta[property="og:description"]')->remove();
            $document->find('head')->append('<meta property="og:description" content="' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (!empty($product->cURLFull)) {
            $document->find('meta[property="og:url"]')->remove();
            $document->find('head')->append('<meta property="og:url" content="' . htmlspecialchars($product->cURLFull, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (!empty($imageUrl)) {
            $document->find('meta[property="og:image"]')->remove();
            $document->find('head')->append('<meta property="og:image" content="' . htmlspecialchars($imageUrl, ENT_QUOTES, 'UTF-8') . '">');
        }
        
        if (isset($product->Preise->fVKBrutto) && $product->Preise->fVKBrutto > 0) {
            $price = number_format((float)$product->Preise->fVKBrutto, 2, '.', '');
            $currency = $_SESSION['Waehrung']->cISO ?? 'EUR';
            
            $document->find('meta[property="product:price:amount"]')->remove();
            $document->find('meta[property="product:price:currency"]')->remove();
            
            $document->find('head')->append('<meta property="product:price:amount" content="' . $price . '">');
            $document->find('head')->append('<meta property="product:price:currency" content="' . $currency . '">');
        }
        
        $availability = 'in stock';
        if (isset($product->fLagerbestand) && (float)$product->fLagerbestand <= 0) {
            if (($product->cLagerBeachten ?? '') === 'Y') {
                $availability = 'out of stock';
            }
        }
        $document->find('meta[property="product:availability"]')->remove();
        $document->find('head')->append('<meta property="product:availability" content="' . $availability . '">');
        
        if (!empty($product->cHersteller)) {
            $document->find('meta[property="product:brand"]')->remove();
            $document->find('head')->append('<meta property="product:brand" content="' . htmlspecialchars($product->cHersteller, ENT_QUOTES, 'UTF-8') . '">');
        }
    }

    private function cleanText(string $text, int $maxLength = 0, bool $stripTags = false): string
    {
        if ($text === '' || $text === null) {
            return '';
        }
        
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        $patterns = [
            '/\bfuer\b/i' => 'für',
            '/\bfrueher\b/i' => 'früher',
            '/\baussen\b/i' => 'außen',
            '/\bgrosse\b/i' => 'große',
            '/\bgrosses\b/i' => 'großes',
            '/\bgrossen\b/i' => 'großen',
            '/\bweiss\b/i' => 'weiß',
            '/\bheiss\b/i' => 'heiß',
            '/\bHoehe\b/' => 'Höhe',
            '/\bhoehe\b/' => 'höhe',
            '/\bLaenge\b/' => 'Länge',
            '/\blaenge\b/' => 'länge',
            '/\bfuehrt\b/i' => 'führt',
            '/\bkoennen\b/i' => 'können',
            '/\bkoennte\b/i' => 'könnte',
            '/\bmuessen\b/i' => 'müssen',
            '/\bwaere\b/i' => 'wäre',
            '/\bwaeren\b/i' => 'wären',
            '/\bueber\b/i' => 'über',
            '/\baehnlich\b/i' => 'ähnlich',
            '/\bAenderung\b/' => 'Änderung',
            '/\baenderung\b/' => 'änderung',
            '/\bOeffnung\b/' => 'Öffnung',
            '/\boeffnung\b/' => 'öffnung',
        ];
        
        foreach ($patterns as $pattern => $replacement) {
            $result = preg_replace($pattern, $replacement, $text);
            if ($result !== null) {
                $text = $result;
            }
        }
        
        $replacements = [
            '/\bFuer\b/' => 'Für',
            '/\bFrueher\b/' => 'Früher',
            '/\bAussen\b/' => 'Außen',
            '/\bGrosse\b/' => 'Große',
            '/\bGrosses\b/' => 'Großes',
            '/\bWeiss\b/' => 'Weiß',
            '/\bHeiss\b/' => 'Heiß',
            '/\bUeber\b/' => 'Über',
        ];
        
        foreach ($replacements as $pattern => $replacement) {
            $result = preg_replace($pattern, $replacement, $text);
            if ($result !== null) {
                $text = $result;
            }
        }
        
        if ($stripTags) {
            $text = strip_tags($text);
        }
        
        $result = preg_replace('/\s+/', ' ', trim($text));
        if ($result !== null) {
            $text = $result;
        }
        
        if ($maxLength > 0 && mb_strlen($text) > $maxLength) {
            $text = mb_substr($text, 0, $maxLength - 3) . '...';
        }
        
        return $text;
    }

    private function makeAbsoluteUrl(string $url, string $shopUrl): string
    {
        if (strpos($url, 'http') === 0) {
            return $url;
        }
        return rtrim($shopUrl, '/') . '/' . ltrim($url, '/');
    }

    /**
     * Decodiert Unterstrich-Encoding: H_e_r_s_t_e_l_l_e_r -> Hersteller
     * Erkennt Pattern: Einzelzeichen_Einzelzeichen_Einzelzeichen...
     */
    private function decodeUnderscoreEncoding(string $text): string
    {
        // Schritt 1: Sonderzeichen-Encoding temporär ersetzen
        // B_l_a_c_k_/_Y_e_l_l_o_w -> B_l_a_c_k###SLASH###Y_e_l_l_o_w
        $text = str_replace('_/_', '###SLASH###', $text);
        $text = str_replace('_-_', '###DASH###', $text);
        $text = str_replace('_+_', '###PLUS###', $text);
        $text = str_replace('_ _', '###SPACE###', $text);
        $text = str_replace('_._', '###DOT###', $text);
        $text = str_replace('_,_', '###COMMA###', $text);
        
        // Schritt 2: Normales Underscore-Decoding
        // Pattern: Ein Zeichen, dann (_Zeichen)+ wiederholt
        // Matched: H_e_r_s_t_e_l_l_e_r, 1_0_0_W, L_E_D
        // Matched NICHT: Angel_Zubehör (weil "Angel" mehr als 1 Zeichen)
        $text = preg_replace_callback(
            '/\b([A-Za-z0-9äöüÄÖÜß])(_[A-Za-z0-9äöüÄÖÜß])+\b/u',
            function($matches) {
                return str_replace('_', '', $matches[0]);
            },
            $text
        ) ?? $text;
        
        // Schritt 3: Platzhalter zurück ersetzen
        $text = str_replace('###SLASH###', '/', $text);
        $text = str_replace('###DASH###', '-', $text);
        $text = str_replace('###PLUS###', '+', $text);
        $text = str_replace('###SPACE###', ' ', $text);
        $text = str_replace('###DOT###', '.', $text);
        $text = str_replace('###COMMA###', ',', $text);
        
        return $text;
    }

    /**
     * Prüft ob ein Text Unterstrich-Encoding enthält
     */
    private function hasUnderscoreEncoding(string $text): bool
    {
        // Prüft auf Muster wie H_e_r_s_t_e_l_l_e_r oder B_l_a_c_k_/_Y_e_l_l_o_w
        return preg_match('/\b[A-Za-z0-9äöüÄÖÜß](_[A-Za-z0-9äöüÄÖÜß])+\b/u', $text) === 1
            || strpos($text, '_/_') !== false
            || strpos($text, '_-_') !== false
            || strpos($text, '_+_') !== false
            || strpos($text, '_ _') !== false;
    }

    /**
     * Transformiert Merkmale: Entfernt Unterstrich-Encoding aus Merkmal-Namen
     * H_e_r_s_t_e_l_l_e_r -> Hersteller
     */
    private function transformWcsMerkmale(array &$args): void
    {
        try {
            if (!$this->checkLicense()) {
                return;
            }

            $artikel = $args['oArtikel'] ?? null;
            if ($artikel === null) {
                return;
            }
            
            $transformed = 0;
            
            // oMerkmale_arr
            if (isset($artikel->oMerkmale_arr) && is_array($artikel->oMerkmale_arr)) {
                foreach ($artikel->oMerkmale_arr as $merkmal) {
                    if ($this->transformSingleMerkmal($merkmal)) {
                        $transformed++;
                    }
                }
            }
            
            // Merkmale
            if (isset($artikel->Merkmale) && is_array($artikel->Merkmale)) {
                foreach ($artikel->Merkmale as $merkmal) {
                    if ($this->transformSingleMerkmal($merkmal)) {
                        $transformed++;
                    }
                }
            }
            
            // FunktionsAttribute
            if (isset($artikel->FunktionsAttribute) && is_array($artikel->FunktionsAttribute)) {
                $newAttributes = [];
                foreach ($artikel->FunktionsAttribute as $key => $value) {
                    $newKey = $this->decodeUnderscoreEncoding($key);
                    if ($newKey !== $key) {
                        $transformed++;
                    }
                    $newAttributes[$newKey] = $value;
                }
                $artikel->FunktionsAttribute = $newAttributes;
            }
            
            if ($transformed > 0) {
                $this->log("Merkmal Transform: $transformed items for article " . ($artikel->kArtikel ?? '?'));
            }
            
        } catch (\Throwable $e) {
            $this->log('Merkmal Transform ERROR: ' . $e->getMessage());
        }
    }

    /**
     * Transformiert einzelnes Merkmal: Entfernt Unterstrich-Encoding
     */
    private function transformSingleMerkmal($merkmal): bool
    {
        if (!is_object($merkmal)) {
            return false;
        }
        
        $transformed = false;
        
        // cName transformieren
        if (isset($merkmal->cName) && $this->hasUnderscoreEncoding($merkmal->cName)) {
            $oldName = $merkmal->cName;
            $merkmal->cName = $this->decodeUnderscoreEncoding($merkmal->cName);
            $this->log("Merkmal decoded: $oldName -> {$merkmal->cName}");
            $transformed = true;
        }
        
        // Sprachversionen transformieren
        if (isset($merkmal->oMerkmalSprache_arr) && is_array($merkmal->oMerkmalSprache_arr)) {
            foreach ($merkmal->oMerkmalSprache_arr as $sprache) {
                if (isset($sprache->cName) && $this->hasUnderscoreEncoding($sprache->cName)) {
                    $sprache->cName = $this->decodeUnderscoreEncoding($sprache->cName);
                    $transformed = true;
                }
            }
        }
        
        // Merkmalwerte transformieren
        if (isset($merkmal->oMerkmalWert_arr) && is_array($merkmal->oMerkmalWert_arr)) {
            foreach ($merkmal->oMerkmalWert_arr as $wert) {
                if (isset($wert->cWert) && $this->hasUnderscoreEncoding($wert->cWert)) {
                    $wert->cWert = $this->decodeUnderscoreEncoding($wert->cWert);
                    $transformed = true;
                }
            }
        }
        
        return $transformed;
    }

    /**
     * Entfernt Unterstrich-Encoding aus dem HTML-Output (für Filter, Breadcrumbs, etc.)
     * H_e_r_s_t_e_l_l_e_r -> Hersteller
     */
    private function removeWcsPrefixFromHtml(array &$args): void
    {
        try {
            // Lizenzprüfung
            if (!$this->checkLicense()) {
                return;
            }

            $doc = $args['document'] ?? null;
            if ($doc === null) {
                return;
            }

            // HTML als String holen
            $html = '';
            if (method_exists($doc, 'html')) {
                $html = $doc->html();
            } elseif (method_exists($doc, '__toString')) {
                $html = (string)$doc;
            }
            
            // Prüfen ob Unterstrich-Encoding vorhanden
            if (empty($html) || !$this->hasUnderscoreEncoding($html)) {
                return;
            }
            
            $originalHtml = $html;
            
            // Unterstrich-Encoding im sichtbaren Text entfernen
            // Pattern: >TEXT< wobei TEXT das Encoding enthält
            $html = preg_replace_callback(
                '/>([^<]+)</u',
                function($matches) {
                    $text = $matches[1];
                    if ($this->hasUnderscoreEncoding($text)) {
                        $text = $this->decodeUnderscoreEncoding($text);
                    }
                    return '>' . $text . '<';
                },
                $html
            );
            
            // Attribute bereinigen: title, alt, aria-label
            $html = preg_replace_callback(
                '/(title|alt|aria-label)="([^"]*)"/i',
                function($matches) {
                    $attr = $matches[1];
                    $value = $matches[2];
                    if ($this->hasUnderscoreEncoding($value)) {
                        $value = $this->decodeUnderscoreEncoding($value);
                    }
                    return $attr . '="' . $value . '"';
                },
                $html
            );
            
            // Nur wenn sich etwas geändert hat, Document aktualisieren
            if ($html !== $originalHtml) {
                $success = false;
                
                if (method_exists($doc, 'loadHtml')) {
                    try {
                        $doc->loadHtml($html);
                        $success = true;
                    } catch (\Throwable $e) {}
                }
                
                if (!$success && method_exists($doc, 'load')) {
                    try {
                        $doc->load($html);
                        $success = true;
                    } catch (\Throwable $e) {}
                }
                
                $this->log('Underscore encoding removed from HTML, reload ' . ($success ? 'successful' : 'failed'));
            }
            
        } catch (\Throwable $e) {
            $this->log('removeUnderscoreEncodingFromHtml ERROR: ' . $e->getMessage());
        }
    }

    /**
     * Output Buffer Callback - entfernt Unterstrich-Encoding aus dem finalen HTML
     * Diese Methode wird aufgerufen BEVOR das HTML an den Browser gesendet wird
     * TEMPLATE-UNABHÄNGIG - funktioniert mit Nova, FLAVOR, EVO und Custom-Templates
     * 
     * Transformiert: H_e_r_s_t_e_l_l_e_r -> Hersteller, 1_0_0_W -> 100W
     */
    private function removeWcsPrefixFromOutput(string $html): string
    {
        try {
            // Lizenzprüfung
            if (!$this->checkLicense()) {
                return $html;
            }

            // Schneller Check ob überhaupt Unterstrich-Encoding vorhanden
            if (empty($html) || !$this->hasUnderscoreEncoding($html)) {
                return $html;
            }
            
            // 1. Sichtbarer Text zwischen HTML-Tags: >H_e_r_s_t_e_l_l_e_r<
            $html = preg_replace_callback(
                '/>([^<]+)</u',
                function($matches) {
                    $text = $matches[1];
                    if ($this->hasUnderscoreEncoding($text)) {
                        $text = $this->decodeUnderscoreEncoding($text);
                    }
                    return '>' . $text . '<';
                },
                $html
            );
            
            // 2. title="H_e_r_s_t_e_l_l_e_r" Attribute
            $html = preg_replace_callback(
                '/(title=")([^"]*)(")/i',
                function($matches) {
                    $value = $matches[2];
                    if ($this->hasUnderscoreEncoding($value)) {
                        $value = $this->decodeUnderscoreEncoding($value);
                    }
                    return $matches[1] . $value . $matches[3];
                },
                $html
            );
            
            // 3. alt="..." Attribute
            $html = preg_replace_callback(
                '/(alt=")([^"]*)(")/i',
                function($matches) {
                    $value = $matches[2];
                    if ($this->hasUnderscoreEncoding($value)) {
                        $value = $this->decodeUnderscoreEncoding($value);
                    }
                    return $matches[1] . $value . $matches[3];
                },
                $html
            );
            
            // 4. aria-label="..." Attribute
            $html = preg_replace_callback(
                '/(aria-label=")([^"]*)(")/i',
                function($matches) {
                    $value = $matches[2];
                    if ($this->hasUnderscoreEncoding($value)) {
                        $value = $this->decodeUnderscoreEncoding($value);
                    }
                    return $matches[1] . $value . $matches[3];
                },
                $html
            );
            
            // 5. data-*="..." Attribute
            $html = preg_replace_callback(
                '/(data-[a-z-]+=")([^"]*)(")/i',
                function($matches) {
                    $value = $matches[2];
                    if ($this->hasUnderscoreEncoding($value)) {
                        $value = $this->decodeUnderscoreEncoding($value);
                    }
                    return $matches[1] . $value . $matches[3];
                },
                $html
            );
            
            // 6. Select-Optionen: <option>H_e_r_s_t_e_l_l_e_r</option>
            $html = preg_replace_callback(
                '/(<option[^>]*>)([^<]*)(<\/option>)/i',
                function($matches) {
                    $text = $matches[2];
                    if ($this->hasUnderscoreEncoding($text)) {
                        $text = $this->decodeUnderscoreEncoding($text);
                    }
                    return $matches[1] . $text . $matches[3];
                },
                $html
            );
            
            return $html;
            
        } catch (\Throwable $e) {
            // Bei Fehler: Original HTML zurückgeben
            return $html;
        }
    }
}
